function join { local IFS="$1"; shift; echo "$*"; }

CURRENT_BRANCH=$(git branch --no-color 2> /dev/null | sed -e '/^[^*]/d' -e 's/* \(.*\)/\1/')

echo "review: $CURRENT_BRANCH"

IFS=',' read -a reviewers <<< "$1"

for i in "${!reviewers[@]}"; do
  reviewers[$i]="r=${reviewers[$i]}@yuanfudao.com"
done


git push origin HEAD:refs/for/$CURRENT_BRANCH%`join , ${reviewers[@]}`