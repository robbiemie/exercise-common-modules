### 学习服务——练习系统——组件库

参考 tutor-box-infrastructure 使用 monorepo 的方式维护，目前只是搭建了架子完成了 vue-audio 标签的封装

#### 项目名字

#### 项目地址

#### 项目初始化

```bash
# 全局安装 lerna
npm i -g lerna

# 安装依赖
npm run bootstrap
```

### 创建新项目

```bash
# example
$ lerna create @tutor/student-exercise-<项目名称>
```

```bash
# 关于 eslint 配置引用外部的配置
# eslint6 不支持 root:true 配置；相关 plugin 等在 root 安装下
npm i -D xxx
```

#### 项目部署

发包脚本虽然 copy 过来，目前还是 npm run build 之后，进到组件的目录里面发布
