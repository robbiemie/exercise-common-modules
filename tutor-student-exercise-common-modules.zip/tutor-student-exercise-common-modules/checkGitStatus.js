const execSync = require('child_process').execSync

try {
    execSync('git pull --rebase')
} catch(error) {
    console.log('Please make sure your git repo is clean')
    process.exit(-1)
}

if (!/.*up.*to.*date.*/.test(execSync('git status -uno', { encoding: 'utf-8'}))) {
    console.log('Please make sure your git repo is update-to-date with remote')
    process.exit(-1)
}
