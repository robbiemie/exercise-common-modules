import React, { useRef, useState } from 'react';
import { Story, Meta } from '@storybook/react';

import {
    Slide,
    SlideProps,
    SlideRefInterface,
    SlideItem,
    Direction
} from './../index';
import './Slide.stories.scss'

export default {
  title: 'Example/Slide',
  component: Slide,
  argTypes: {
    backgroundColor: { control: 'color' },
  },
} as Meta;

const BasicTemplate: Story<SlideProps> = (args) => {
  let params = {
    ...args,
    showDots: true,
    direction: Direction.Horizontal,
  }
  const slideRef = useRef<null | SlideRefInterface>(null)

  return (
    <div className="normal-slide">
      <div>横向播放</div>
      <Slide ref={slideRef} {...params}>
        <SlideItem>1</SlideItem>
        <SlideItem>2</SlideItem>
        <SlideItem>3</SlideItem>
        <SlideItem>4</SlideItem>
      </Slide>
      <div className="slide-btn" onClick={() => {
        slideRef.current!.invoke('prev')
      }}>上一页</div>
      <div className="slide-btn" onClick={() => {
        slideRef.current!.invoke('next')
      }}>下一页</div>
      <div className="slide-btn" onClick={() => {
        slideRef.current!.gotoPage(2)
      }}>跳转到第三页</div>
    </div>
  )
}

const VerticalTemplate: Story<SlideProps> = (args) => {
  let params = {
    ...args,
    direction: Direction.Vertical
  }
  const slideRef = useRef<null | SlideRefInterface>(null)

  return (
    <div className="normal-slide">
      <div>纵向播放</div>
      <Slide ref={slideRef} {...params}>
        <SlideItem>1</SlideItem>
        <SlideItem>2</SlideItem>
        <SlideItem>3</SlideItem>
        <SlideItem>4</SlideItem>
      </Slide>
      <div className="slide-btn" onClick={() => {
        slideRef.current!.invoke('prev')
      }}>上一页</div>
      <div className="slide-btn" onClick={() => {
        slideRef.current!.invoke('next')
      }}>下一页</div>
      <div className="slide-btn" onClick={() => {
        slideRef.current!.gotoPage(2)
      }}>跳转到第三页</div>
    </div>
  )
}

const LoopTemplate: Story<SlideProps> = (args) => {

  let params = {
    ...args,
    showDots: true,
    direction: Direction.Horizontal,
    options: {
      slide: {
        speed: 100,
        loop: true,
        autoplay: true
      }
    },
    onCurPageChange: getSlideCurPage
  }
  let [currentPage, setCurrentPage] = useState(0)
  function getSlideCurPage(curPage: number) {
    setCurrentPage(curPage)
  }
  const slideRef = useRef<null | SlideRefInterface>(null)

  return (
    <div className="normal-slide">
      <div>循环播放</div>
      <Slide ref={slideRef} {...params}>
        <SlideItem>1</SlideItem>
        <SlideItem>2</SlideItem>
        <SlideItem>3</SlideItem>
        <SlideItem>4</SlideItem>
      </Slide>
      <div>当前页面索引: {currentPage}</div>
      <div className="slide-btn" onClick={() => {
        slideRef.current!.invoke('prev')
      }}>上一页</div>
      <div className="slide-btn" onClick={() => {
        slideRef.current!.invoke('next')
      }}>下一页</div>
    </div>
  )
}

export const Basic = BasicTemplate.bind({});
export const Vertical = VerticalTemplate.bind({})
export const Loop = LoopTemplate.bind({})
