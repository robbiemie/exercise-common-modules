import React, { ReactNode } from 'react'
import './SlideItem.css'

export interface SlideItemProps {
  id?: string
}
type PropsWithChildren<P> = P & { children?: ReactNode }

const SlideItem = (props: PropsWithChildren<SlideItemProps>) => {
  return <div key={props.id} className='slide-item'>
    {props.children}
  </div>
}

export default SlideItem
