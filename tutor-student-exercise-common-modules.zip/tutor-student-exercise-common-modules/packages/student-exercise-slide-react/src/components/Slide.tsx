import React, { useEffect, useState, useRef, forwardRef, useImperativeHandle } from 'react';
import BScroll, { Options as BsOptions } from '@better-scroll/core'
import {
    TouchEvent,
  } from '@better-scroll/shared-utils'
import Slider from '@better-scroll/slide'
import classnames from 'classnames'
import { EventType, Position, Direction, DEFAULT_SLIDE_CONFIG } from '../common/constants'
import './Slide.css';

BScroll.use(Slider)
interface SlideConfig {
    loop?: boolean;
    threshold?: number;
    speed?: number;
    easing?: {
        style: string;
        fn: (t: number) => number;
    };
    listenFlick?: boolean;
    autoplay?: boolean;
    interval?: number;
}
export interface Options {
  listenScroll?: boolean; // 是否监听滚动事件，默认为 false, 开启可能影响性能
  slide?: SlideConfig;
}

export interface SlideRefInterface {
  invoke: (eventName: string, args?: any) => void;
  refresh: () => void;
  gotoPage: (page: number, time?: number, easing?: string) => void
}

export interface SlidePage {
  x: number;
  y: number;
  pageX: number;
  pageY: number;
}

export interface SlideProps {
  /**
   * slides 数据源
   */
  dataSource?: [];
  /**
   * slide 配置
   * https://better-scroll.github.io/docs/zh-CN/guide/base-scroll-options.html
   */
  options?: Options & BsOptions;
  /**
   * 是否显示坐标点
   */
  showDots?: boolean;
  /**
   * 滑动方向
   */
  direction?: Direction;
  /**
   * 是否开启自适应
   */
  autoResize?: boolean;
  onSlideResize?: () => void
  /**
   * slide 初始化完成回调
   * @param page: 返回起始页位置
   */
  onSlideCreated?: (page: number) => void
  onSlideWillChange?: (currentPage: number) => void
  onSlideDestory?: () => void
  onSelected?: () => void
  onBeforeScrollStart?: (event: TouchEvent) => void
  onScrollStart?: (event: TouchEvent) => void
  onScroll?: (pos: Position) => void
  /**
   * 滑动动画结束
   * @param page: 滑动结束时，当前页码数
   */
  onScrollEnd?: (page: number) => void
  onTouchEnd?: (event: TouchEvent) => void
  onScrollCancel?: () => void
  /**
   * 触发翻页更新
   * @param currentPage: 当前页码数
   */
  onCurPageChange?: (currentPage: number) => void
}

type PropsWithChildren<T> = T & { children?: any }

/**
 * Primary UI component for user interaction
 */
const Slide = ({
  dataSource,
  options,
  showDots,
  direction,
  autoResize,
  onScroll,
  onScrollEnd,
  onTouchEnd,
  onScrollStart,
  onScrollCancel,
  onCurPageChange,
  onBeforeScrollStart,
  onSlideCreated,
  onSlideDestory,
  onSlideWillChange,
  ...props
}: PropsWithChildren<SlideProps>, ref: any) => {
  const [dots, setDots] = useState<any>([])
  const [currentPage, setCurrentPage] = useState(0)
  const currentPageRef = useRef(0)
  const dotsRef = useRef<null | HTMLDivElement>(null)
  const slideRef = useRef<null | HTMLDivElement>(null)
  const slideGroupRef = useRef<null | HTMLDivElement>(null)
  const [bSroll, setBScroll] = useState<null | BScroll>(null)
  const slideChildrenRef = useRef<null | HTMLCollection>(null)
  useEffect(() => {
    if (bSroll) return
    // console.log('创建 slide 组件')
    updateSlideItemDom()
    createSlide()
    updateDotsDom()
  }, [bSroll])
  useEffect(() => {
      if(!bSroll) return
      return () => {
        destorySlide()
      }
  }, [bSroll])
  useEffect(() => {
    updateDotsResize()
  }, [dots])
  useImperativeHandle(ref, (): PropsWithChildren<SlideRefInterface> => ({
    /**
     * 调用 slide 组件原生 API
     * API: https://better-scroll.github.io/docs/zh-CN/plugins/slide.html#slidewillchange
     * @param eventName
     * @param args
     */
    invoke(eventName: string, args: any) {
      let params = args ? args : [undefined]
      if (bSroll && bSroll[eventName]) {
        bSroll[eventName].apply(bSroll, params)
      } else {
        console.warn(`${eventName} 调用方法不存在, 请检查是否存在该方法，或检测大小写是否正确`)
      }
    },
    refresh,
    gotoPage
  }))
  const refresh = () => {
      if(bSroll) {
        bSroll.refresh()
      }
  }
  const updateDotsDom = () => {
    if (dots.length) return
    let slideItemSize = getSlideItemSize()
    let dotList = Array.from({
      length: slideItemSize
    })
    setDots(dotList)
  }
  const updateDotsResize = () => {
    let dotsEl = dotsRef.current
    let slideEl = slideRef.current
    if(dotsEl && slideEl) {
        let dotEl = dotsEl.children[0]
        if(dotEl) {
            // @ts-ignore
            let dotsWidth = dotEl.getBoundingClientRect().width
            let slideItemSize = getSlideItemSize()
            // 动态设置宽度
            dotsEl.style.width = slideItemSize * dotsWidth + 'px'
            dotsEl.style.left = (slideEl.getBoundingClientRect().width / 2) - (dotsWidth * slideItemSize) / 2  + 'px'
            dotsEl.style.visibility = 'visible'
        }
    }
  }
  const handleSlideWillChange = (page: SlidePage) => {
    const { pageX, pageY } = page
    let currentPageNew = direction === Direction.Horizontal ? pageX : pageY

    onSlideWillChange && onSlideWillChange(currentPageNew)
  }
  const handleSlidePageChanged = (page: SlidePage) => {
    const { pageX, pageY } = page
    let currentPageNew = direction === Direction.Horizontal ? pageX : pageY
    if (currentPageNew !== currentPageRef.current) {
      let slideItemSize = getSlideItemSize()
      // 页面更新
      currentPageRef.current = currentPageNew % slideItemSize
      setCurrentPage(currentPageRef.current)
      onCurPageChange && onCurPageChange(currentPageRef.current)
    }
  }
  const handleScrollEnd = (slide: BScroll) => {
    if (!slide) return
    const { pageX, pageY } = slide.getCurrentPage()
    let currentPageNew = direction === Direction.Horizontal ? pageX : pageY
    onScrollEnd && onScrollEnd(currentPageNew)
  }
  const getSlideItemSize = () => {
    if (!slideChildrenRef.current) return 0
    // @ts-ignore
    let size = slideChildrenRef.current!.length || 0
    if (options?.slide?.loop && size > 1) {
      // loop 模式会额外插入两个dom节点，需要单独处理
      size -= 2
    }
    return size
  }
  /**
   * 动态更新 slide 子节点，尺寸信息
   */
  const updateSlideItemDom = () => {
    let slideEl = slideRef.current
    let slideGroupEl = slideGroupRef.current
    if (!slideGroupEl || !slideEl) return
    let children = slideGroupEl.children
    slideChildrenRef.current = children
    const target = direction === Direction.Horizontal ? 'width' : 'height'
    let allSize = 0
    const slideSize = (slideEl as any)[`client${target[0].toUpperCase() + target.slice(1)}`]
    const len = children.length
    for (let i = 0; i < len; i++) {
      const child = children[i] as HTMLElement
      child.style[target] = slideSize + 'px'
    }
    allSize = getSlideItemSize() * slideSize
    slideGroupEl.style[target] = allSize + 'px'
  }

  /**
   * 跳转页面
   * @param page 将要跳转的页面
   * @param time 滑动时间，默认 400ms，当值为0时，表示立即切换
   * @param easing 运动函数
   * @returns
   */
  const gotoPage = (page: number, time: number = 400, easing: string = 'bounce') => {
    if (!bSroll) return
    if (direction === Direction.Horizontal) {
      bSroll.goToPage(page, 0, time, easing)
    } else {
      bSroll.goToPage(0, page, time, easing)
    }
  }
  const getSlideOptions = () => {
    let slideOptions = Object.assign({}, DEFAULT_SLIDE_CONFIG.slide)
    if (options?.slide) {
      slideOptions = Object.assign(slideOptions, options.slide)
    }
    return {
      ...DEFAULT_SLIDE_CONFIG,
      ...options,
      scrollX: direction === Direction.Horizontal,
      scrollY: direction === Direction.Vertical,
      slide: slideOptions
    }
  }
  const handleResize = () => {
      // 动态更新 dots
      updateDotsResize()
  }
  const createSlide = () => {
    const bsOptions: BsOptions = getSlideOptions()
    let bSrollInstance = new BScroll('.slide', bsOptions)
    setBScroll(bSrollInstance)
    addEventListener(bSrollInstance, bsOptions)
    // 立即跳转到起始页
    // gotoPage(currentPageRef.current, 0)
    if (onSlideCreated) {
      onSlideCreated(currentPageRef.current)
    }
    return bSrollInstance
  }
  const addEventListener = (slide: BScroll, slideOptions: BsOptions) => {
    slide.on(EventType.SCROLLEND, handleScrollEnd.bind(null, slide))
    if (slideOptions.listenScroll && slideOptions.probeType === 3 && onScroll) {
      slide.on(EventType.SCROLL, onScroll)
    }
    if(onTouchEnd) {
      slide.on(EventType.TOUCHEND, onTouchEnd)
    }
    if (onBeforeScrollStart) {
      slide.on(EventType.BEFORESCROLLSTART, onBeforeScrollStart)
    }
    if (onScrollStart) {
      slide.on(EventType.SCROLLSTART, onScrollStart)
    }
    if (onScrollCancel) {
      slide.on(EventType.SCROLLCANCEL, onScrollCancel)
    }
    slide.on(EventType.SLIDEWILLCHANGE, handleSlideWillChange)
    slide.on(EventType.SLIDEPAGECHANGED, handleSlidePageChanged)
    window.addEventListener('resize', handleResize)
  }


  const destorySlide = () => {
    if (bSroll) {
    //   console.log('销毁 slide 组件', bSroll)
      bSroll!.destroy()
      setBScroll(null)
      slideChildrenRef.current = null
      onSlideDestory && onSlideDestory()
    }
    window.removeEventListener('resize', handleResize)

  }
  return (
    <div className="slide" ref={slideRef}>
      <div className="slide-group" ref={slideGroupRef}>
        {props.children}
      </div>
      {
        showDots ?
          <div className="slide-dots" ref={dotsRef}>
            {dots.map((item: any, index: number) => {
              return <span key={index} className={classnames('slide-dot', {
                'slide-dot-active': index === currentPage
              })}></span>
            })}
          </div> : null
      }
    </div>
  );
};

export default forwardRef(Slide)
