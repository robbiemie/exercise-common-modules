export const deepClone = (target:any, map = new Map()) => {
    if(typeof target === 'object') {
        let cloneTarget:any = Array.isArray(target) ? [] : {}
        if(map.get(target)) {
            return map.get(target)
        }
        map.set(target, cloneTarget)
        for(let key in target) {
            cloneTarget[key] = deepClone(target[key], map)
        }
        return cloneTarget
    } else {
        return target
    }
}
