export enum EventType {
  CHANGE = 'change',
  BEFORESCROLLSTART = 'beforeScrollStart',
  SCROLLSTART = 'scrollStart',
  SCROLLEND = 'scrollEnd',
  SCROLLCANCEL = 'scrollCancel',
  SCROLL = 'scroll',
  SELECT = 'click',
  TOUCHEND = 'touchEnd',
  SLIDECREATED = 'slideCreated',
  SLIDEDESTROYED = 'slideDestroyed',
  SLIDEWILLCHANGE = 'slideWillChange',
  SLIDEPAGECHANGED = 'slidePageChanged',
  RESIZE = 'resize'
}

export enum Direction {
  Horizontal = 'horizontal',
  Vertical = 'vertical'
}

export interface Position {
  x: number;
  y: number;
}

export const DEFAULT_SLIDE_CONFIG = {
  momentum: false,
  click: true,
  observeDOM: false,
  bounce: false,
  slide: {
    autoplay: false, // 默认关闭自动播放
    loop: false, // 默认关闭循环播放
    threshold: 0.3, // 翻页切换阈值
    speed: 300
  }
}
