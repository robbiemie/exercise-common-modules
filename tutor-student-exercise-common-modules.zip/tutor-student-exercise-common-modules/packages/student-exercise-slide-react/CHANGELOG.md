# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

### [0.1.17](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/compare/v0.1.15...v0.1.17) (2021-07-20)

### [0.1.16](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/compare/v0.1.15...v0.1.16) (2021-07-20)

### [0.1.15](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/compare/v0.1.14...v0.1.15) (2021-07-20)

### [0.1.14](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/compare/v0.1.7...v0.1.14) (2021-07-20)


### Features

* 提取学校选择器公共组件 ([ff58251](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/ff58251db5ffbbc88895d0a75392d7c9bf5460c5))


### Bug Fixes

* 修复学校列表未高亮选中项，以及iOS下打开学校选择器后滚动穿透问题 ([e05d8af](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/e05d8af67c606834ccbe2dd044e22303368bff0e))

### [0.1.13](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/compare/v0.1.7...v0.1.13) (2021-07-20)


### Features

* 提取学校选择器公共组件 ([ff58251](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/ff58251db5ffbbc88895d0a75392d7c9bf5460c5))


### Bug Fixes

* 修复学校列表未高亮选中项，以及iOS下打开学校选择器后滚动穿透问题 ([e05d8af](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/e05d8af67c606834ccbe2dd044e22303368bff0e))

### [0.1.12](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/compare/v0.1.7...v0.1.12) (2021-07-16)

### [0.1.11](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/compare/v0.1.7...v0.1.11) (2021-07-16)

### [0.1.10](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/compare/v0.1.7...v0.1.10) (2021-06-15)

### [0.1.9](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/compare/v0.1.7...v0.1.9) (2021-06-09)

### [0.1.8](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/compare/v0.1.7...v0.1.8) (2021-06-09)

### [0.1.7](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/compare/v0.1.3...v0.1.7) (2021-06-09)

### [0.1.6](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/compare/v0.1.3...v0.1.6) (2021-06-09)

### [0.1.5](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/compare/v0.1.3...v0.1.5) (2021-06-09)

### [0.1.4](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/compare/v0.1.3...v0.1.4) (2021-06-08)

### [0.1.3](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/compare/v0.1.2...v0.1.3) (2021-06-04)

### [0.1.2](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/compare/v0.1.1...v0.1.2) (2021-06-04)

### 0.1.1 (2021-06-04)


### Features

* 新增 slide 组件类型定义 ([cd76180](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/cd761802be819a33af6df45d355c2b1967e7492a))


### Bug Fixes

* 修改轮播自动停止问题 ([f4413b8](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/f4413b8857ae55495b41e47a49ca7ab31e72fd8b))
