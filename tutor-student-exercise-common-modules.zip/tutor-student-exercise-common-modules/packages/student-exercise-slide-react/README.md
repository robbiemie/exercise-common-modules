# Getting Started with Create React App

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Available Scripts

In the project directory, you can run:

### `npm run start:storybook`

启动本地 storybook 文档服务


## `npm run release`

构建发布 npm 包

## `npm publish`

发布



## 踩坑指南


### 问题描述

本地调试包，遇到一下问题：

```log
Error: Invalid hook call. Hooks can only be called inside of the body of a function component. This could happen for one of the following reasons:
1. You might have mismatching versions of React and the renderer (such as React DOM)
2. You might be breaking the Rules of Hooks
3. You might have more than one copy of React in the same app
See https://fb.me/react-invalid-hook-call for tips about how to debug and fix this problem.
```

### 问题原因

react hook 为了保证正常工作，必须使用相同的 react 版本，之前由于对 raect 安装使用 `npm install --save`，因此才会导致 react 版本不一致的问题。

### 解决方案

因此，开发第三方库的时候，必须使用 `peerDependencies` 对 react 版本进行统一处理。

```json
  "peerDependencies": {
    "react": ">=17",
    "react-dom": ">=17"
  }
```

https://segmentfault.com/a/1190000022435060
