module.exports = {
    plugins: {
        'autoprefixer': {}
    }
}
