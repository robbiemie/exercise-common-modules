# `tutor-student-exercise-common-schoolinput`

学校选择器组件，UI样式可见问卷中的学校选择器组件

## Usage

### 导出元素
* SchoolInput ：学校选择器组件（内部使用了 SchoolSelect），使用该组件则无需使用 SchoolSelect
* SchoolSelect ： 学校选择框组件（搜索 + 学校列表显示）
* SchoolInputType ： 组件内数据类型定义

### 属性定义

#### SchoolInput 组件

props | 类型 | 作用
--|:--:|--
value | { id: number, name: string } | 当前选中学校
readonly | Boolean | 是否只读，为 true 时无法点击修改选中
@change | Function | 选择学校变化回掉
getSchoolList | async Function(keywords: string) : Array | 根据关键字获取学校列表的方法，需要返回数组，每项类型为 { id: number, name: string }

#### SchoolSelect 组件

props | 类型 | 作用
--|:--:|--
curSelectedSchool | { id: number, name: string } | 当前选中的学校（组件内部据此标红当前选中项）
getSchoolList | async Function(keywords: string) : Array | 根据关键字获取学校列表的方法，需要返回数组，每项类型为 { id: number, name: string }
@close | Function | 关闭组件回调
@selected | Function | 选中学校回调

#### SchoolInputType
```
interface School {
    id: number
    name: string
}
```

### 引入方法
```
// 下载 npm 包
npm install --save @tutor/student-exercise-common-school-input

// 引入组件及 css 样式
import { SchoolInput } from "@tutor/student-exercise-common-school-input";
import "@tutor/student-exercise-common-school-input/dist/student-exercise-common-school-input.css";
```

### 示例代码

```vue
<template>
  <div id="app">
    <div class="top"></div>
    <SchoolInput
      :value="curSchool"
      :getSchoolList="getSchoolList"
      @change="onChange"
    >
      <template v-slot:search-loading>
        <span>Data Loading……</span>
      </template>
    </SchoolInput>
    <div class="bottom"></div>
  </div>
</template>

<script lang="ts">
import Vue from "vue";
import { Component } from "vue-property-decorator";
import {
  SchoolInput,
  SchoolInputType,
} from "@tutor/student-exercise-common-school-input";
import "@tutor/student-exercise-common-school-input/dist/student-exercise-common-school-input.css";

const demoSchoolData: SchoolInputType.School[] = [
    { id: 1024881, name: "北京小学" },
    { id: 1024505, name: "北京英国学校" },
    { id: 1024653, name: "北京进步小学" },
    { id: 1024665, name: "北京·通州·芙蓉小学" },
    { id: 1024663, name: "北京小学天宁寺分校" },
    { id: 1024893, name: "北京小学红山分校" },
    { id: 1024921, name: "北京十一丰台小学" },
    { id: 1025075, name: "北京小学大兴分校" },
    { id: 1025321, name: "北京小学走读部" },
    { id: 1025341, name: "北京小学分校" },
    { id: 1025329, name: "北京雷锋小学" },
    { id: 1025373, name: "北京小学通州分校" },
    { id: 1025965, name: "北京力学小学" },
    { id: 1027113, name: "北京新希望学校" },
    { id: 1026635, name: "北京朝阳外语小学" },
    { id: 1026789, name: "北京金海河学校" },
    { id: 1026897, name: "北京燕山向阳小学" },
    { id: 1027231, name: "北京群英希望小学" },
    { id: 1027323, name: "北京铁路实验小学" }
]

(SchoolInput as any).install(Vue);

@Component({})
export default class App extends Vue {
  schoolData: SchoolInputType.School[] = [];
  debounceInputkeyword: any;
  curSchool = { id: 1024881, name: "北京小学" }; // 初始值

  onChange(selectedSchool: SchoolInputType.School) {
    this.curSchool = selectedSchool;
  }

  onInputChange(inputvalue: string) {
    console.log("onInputChange", inputvalue);
  }

  filterSchoolList(keywords: string) {
    return demoSchoolData.filter(item => {
      return item.name.indexOf(keywords) >= 0
    })
  }

  async getSchoolList(keywords: string) {
    let schoolList: SchoolInputType.School[] = await new Promise(
      (resolve, reject) => {
        setTimeout(() => {
          const newSchoolList = this.filterSchoolList(keywords);
          resolve(newSchoolList);
        }, 1000);
      }
    );
    return schoolList;
  }
}
</script>

```
