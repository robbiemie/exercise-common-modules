<template>
    <div class='school-select-wrapper'>
        <!-- 搜索文本框 -->
        <div class="search-wrapper">
            <div class="search-content">
                <div class="search-icon">
                    <img src="../assets/search.png" width="16" height="16">
                </div>
                <input type="text" class="input-search" v-model="inputVal" placeholder="请输入完整的学校名称" @input="debounceInputkeyword">
            </div>
            <div class="cancel-btn" @click="closeSelect">
                取消
            </div>
        </div>
        <!-- 搜索loading -->
        <div class="search-loading" v-if="showSearchLoading">
            <slot name="search-loading">Loading...</slot>
        </div>
        <!-- 搜索列表 -->
        <div class="search-list" v-else-if="showSearchList">
            <ul class="search-result" @click="selectSchool">
                <li v-for="(school, index) in schoolList" :key="index" class="school-item"  :class="{'current-item': school.id === curSelectedSchoolId}" :data-id="school.id">{{school.name}}</li>
            </ul>
        </div>
        <!-- 没有搜索到内容 -->
        <div class="search-no-data" v-else-if="showNoData">
            <div class="no-data-text">
                未搜索到学校，点击确定可将输入框信息作为学校填入
            </div>
            <div class="confirm-btn" @click="setNotSelected">确定</div>
        </div>
    </div>
</template>
<script lang='ts'>
import Vue from 'vue'
import { Component, Prop } from 'vue-property-decorator'
import { SchoolInputType } from '../types'
import debounce from 'lodash/debounce'

enum SearchStatus {
    'INIT',
    'LOADING',
    'END'
}

interface ScrollFix {
    enable: () => void,
    disable: () => void
}

@Component({})
export default class SchoolSelect extends Vue {
    @Prop() getSchoolList! : (keywords: string) => Promise<SchoolInputType.School[]>
    @Prop() curSelectedSchool! : SchoolInputType.School

    debounceInputkeyword: () => void = () => {}
    selectedSchool: SchoolInputType.School | null = null
    searchStatus: SearchStatus = SearchStatus.INIT
    inputVal: string = ''
    selectedId: number = -1
    schoolList: SchoolInputType.School[] = []
    scrollFixHelper: ScrollFix | null = null


    get keyword() {
        const reg = /[^a-zA-Z0-9\u4e00-\u9fa5\u3002\uff0c\uff1a\uff08\uff09\uff1f\u201c\u201d\u3001\uff01,/.!:()?_""—-]/g
        return this.inputVal.replace(reg, '')
    }

    get showSearchList() {
        return this.schoolList.length > 0
    }

    get showSearchLoading() {
        return this.searchStatus === SearchStatus.LOADING
    }

    get showNoData() {
        return this.searchStatus === SearchStatus.END && this.keyword
    }

    get curSelectedSchoolId() {
        return this.curSelectedSchool?.id
    }

    created () {
        this.debounceInputkeyword = debounce(() => {
            this.innerGetSchoolList()
        }, 300)
        // 处理滚动穿透问题
        this.scrollFixHelper = this.scrollFix()
        this.scrollFixHelper?.enable()
    }

    beforeDestroy () {
        this.scrollFixHelper?.disable()
    }

    selectSchool (e: Event) {
        const target = e.target as HTMLElement
        const id = target.getAttribute('data-id') || '0'
        const name = target.innerText
        this.selectedSchool = {
            id: Number.parseInt(id, 10),
            name,
        }
        this.selectedId = Number.parseInt(id, 10)
        this.postSelectedSchool()
        this.closeSelect()
    }

    closeSelect () {
        this.$emit('close')
    }

    postSelectedSchool () {
        this.$emit('selected', this.selectedSchool)
    }

    setNotSelected () {
        this.selectedSchool = {
            id: -1,
            name: this.keyword
        }

        this.postSelectedSchool()
        this.closeSelect()
    }


    async innerGetSchoolList () {
        if(!this.keyword) {
            this.initSchoolSelect()
            return
        }
        this.searchStatus = SearchStatus.LOADING
        try {
            this.schoolList = await this.getSchoolList(this.keyword)
        }catch(e) {
            this.schoolList = []
        }
        this.searchStatus = SearchStatus.END
    }

    initSchoolSelect () {
        this.searchStatus = SearchStatus.INIT
        this.schoolList = []
    }

    /**
     * 处理滚动穿透问题，选择框打开时设置 body overflow：hidden 可以解决滚动穿透问题，但 iOS 软键盘弹起时滚动仍有问题，留待后面解决吧
     */
    scrollFix () {
        let scrollTop: number = 0
        let className = 'tutor-student-exercise-common-school-select-scrollfix'
        return {
            enable: () => {
                // 先记录 body 当前滚动位置，然后添加样式把 body 的滚动禁掉
                scrollTop = document.body.scrollTop || document.scrollingElement?.scrollTop || window.scrollY
                document.body.classList.add(className)
            },
            disable: () => {
                document.body.classList.remove(className)
                // 从 overflow: hidden 恢复后需要还原页面的滚动位置
                if(document.scrollingElement) {
                    document.scrollingElement.scrollTop = scrollTop
                }else {
                    window.scrollTo(0, scrollTop)
                }
                scrollTop = 0
            }
        }
    }
}
</script>
<style lang="less">
.tutor-student-exercise-common-school-select-scrollfix {
    overflow: hidden;
    position: fixed;
}
</style>
<style lang='less' scoped>
.school-select-wrapper {
    position: fixed;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    z-index: 999;
    background: #fff;
    display: flex;
    flex-direction: column;

    .search-wrapper {
        height: 69px;
        padding: 16px;
        display: flex;
        justify-content: flex-start;
        align-items: center;
        border-bottom: 1px solid rgba(0, 0, 0, 0.15);
        box-sizing: border-box;

        .search-content {
            flex: 1;
            height: 36px;
            background: #f5f5f5;
            border-radius: 4px;
            display: flex;

            .search-icon {
                width: 32px;
                line-height: 40px;
                text-align: center;
                img {
                    vertical-align: baseline;
                }
            }

            .input-search {
                flex: 1;
                background: #f5f5f5;
                border: none;
                outline: none;
                caret-color: #ff7400;
            }
        }
        .cancel-btn {
            margin-left: 16px;
            font-size: 15px;
            line-height: 36px;
            font-family: PingFang SC;
            color: #666;
        }
    }

    .search-no-data {
        width: 60%;
        margin: 32px auto;

        .no-data-text {
            font-family: PingFang SC;
            font-size: 15px;
            line-height: 22px;
            text-align: center;
            color: #999;
        }

        .confirm-btn {
            margin: 16px auto;
            width: 120px;
            height: 32px;
            color: #fff;
            background: #ff7400;
            border-radius: 16px;
            text-align: center;
            line-height: 32px;
            font-size: 13px;
        }
    }

    .search-list {
        flex: 1;
        padding: 0 16px;
        font-family: PingFang SC;
        overflow: auto;

        .search-result {
            list-style: none;
            padding: 0;

            .school-item {
                min-height: 52px;
                background: rgba(0, 0, 0, 0.0001);
                box-shadow: inset 0px -0.5px 0px #e8e8e8;
                font-size: 16px;
                color: #222;
                display: flex;
                align-items: center;

                &.current-item {
                    color:#FF7400;
                }
            }
        }
    }

    .search-loading {
        flex: 1;
        display: flex;
        justify-content: center;
        align-items: flex-start;
        padding-top: 200px;
    }
}
</style>
