<template>
    <div class='school-input-wrapper'>
        <div class="input-wrap" @click="openSelectSchool">
            <span class="icon-search">
                <img src="../assets/school.png" width="19" height="19">
            </span>
            <span class="result-search">
                {{SchoolName}}
            </span>
        </div>
        <SchoolSelect
            :getSchoolList="getSchoolList"
            :curSelectedSchool="value"
            @close="coloseSelect"
            @selected="selectedSchool"
            v-if="showSelectSchool"
        >
            <template v-slot:search-loading>
                <slot name="search-loading"></slot>
            </template>
        </SchoolSelect>
    </div>
</template>
<script lang='ts'>
import Vue from 'vue'
import { Component, Prop } from 'vue-property-decorator'
import { SchoolInputType } from '../types'
import SchoolSelect from './SchoolSelect.vue'

@Component({
    components: {
        SchoolSelect
    }
})
export default class SchoolInput extends Vue {
    @Prop({ default: false }) readonly! : boolean
    @Prop({ default: null }) value! : SchoolInputType.School | null
    @Prop() getSchoolList! : (keywords: string) => Promise<SchoolInputType.School[]>

    showSelectSchool: boolean = false
    timer:  number | null = null

    get SchoolName() {
        return this.value?.name || ''
    }

    openSelectSchool() {
        if(this.readonly) {
            return
        }
        this.showSelectSchool = true
    }

    selectedSchool(selectedSchool: SchoolInputType.School) {
        this.$emit('change', selectedSchool)
    }

    coloseSelect() {
        if(this.timer) {
            return
        }
        this.timer = window.setTimeout(() => {
            this.showSelectSchool = false
            window.clearTimeout(this.timer as number)
            this.timer = null
        }, 200)
    }
}
</script>
<style lang='less' scoped>
.school-input-wrapper {
    width: 100%;

    .input-wrap {
        height: 60px;
        border: 1px solid #f5f5f5;
        border-radius: 10px;
        line-height: 60px;
        display: flex;

        .icon-search {
            padding-left: 14px;
            align-self: center;
            img {
                vertical-align: baseline;
            }
        }

        .result-search {
            flex: 1;
            height: 60px;
            align-self: center;
            padding-left: 10px;
            font-family: PingFang SC;
            font-size: 16px;
            line-height: 60px;
            /* identical to box height, or 162% */
            letter-spacing: 0.01em;
            /* Gray_02 */
            color: #4D4D4D;

            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
    }
}
</style>
