export namespace SchoolInputType {
    export interface School {
        id: number
        name: string
    }
}
