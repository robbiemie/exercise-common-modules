import { VueConstructor } from 'vue'
import SchoolInput from './components/SchoolInput.vue'
import SchoolSelect from './components/SchoolSelect.vue'
import { SchoolInputType } from './types'

(SchoolInput as any).install = (Vue: VueConstructor) => {
    Vue.component('SchoolInput', SchoolInput)
}

(SchoolSelect as any).install = (Vue: VueConstructor) => {
    Vue.component('SchoolSelect', SchoolSelect)
}

export {
    SchoolInput,
    SchoolSelect,
    SchoolInputType
}
