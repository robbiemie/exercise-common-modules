module.exports = {
    "extends": "../../.eslintrc.js"
};
