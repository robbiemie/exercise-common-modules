# `@tutor/student-exercise-seed`

> TODO: description

## Usage

```
const studentExerciseSeed = require('@tutor/student-exercise-seed');

// TODO: DEMONSTRATE API
```
