'use strict';

const studentExerciseSeed = require('..');

describe('@tutor/student-exercise-seed', () => {
    it('needs tests');
});
