module.exports = {
    "extends": "../../.eslintrc.js",
    "rules": {
        "id-blacklist": [
            "error",
            "any",
            "Number",
            "Boolean",
            "Undefined",
        ],
    }
};
