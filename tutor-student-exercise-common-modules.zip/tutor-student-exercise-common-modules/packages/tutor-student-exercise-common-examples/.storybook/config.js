import { configure, addParameters, addDecorator } from '@storybook/vue'
import { setConsoleOptions } from '@storybook/addon-console'
import { withKnobs } from '@storybook/addon-knobs'
import { INITIAL_VIEWPORTS } from '@storybook/addon-viewport'

setConsoleOptions({
    panelExclude: []
})

addDecorator(() => {
    return {
        template: '<div style="padding: 1rem;"><story/></div>'
    }
})

addDecorator(withKnobs)

addParameters({
    options: {
        panelPosition: 'right'
    },
    viewport: {
        defaultViewport: 'iphonex',
        viewports: {
          ...INITIAL_VIEWPORTS,
          PC: {
            name: 'PC',
            styles: {
              width: '1040px',
              height: '720px'
            }
          }
        }
    }
})

// automatically import all files ending in *.stories.ts
const req = require.context('../src', true, /\.stories\.ts$/)

function loadStories() {
    req.keys().forEach(filename => req(filename))
}

configure(loadStories, module)
