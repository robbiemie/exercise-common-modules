const merge = require('webpack-merge')
const customConfig = require('@vue/cli-service/webpack.config.js')

module.exports = async ({ config }) => {
  const result = {
    ...customConfig,
    entry: config.entry,
    output: config.output,
    plugins: merge({
      customizeArray: merge.unique(
        'plugins',
        [
          'HtmlWebpackPlugin',
          'HotModuleReplacementPlugin',
          'VueLoaderPlugin'
        ],
        plugin => plugin.constructor && plugin.constructor.name
      )
    })(config, customConfig).plugins,
    resolve: {
      ...customConfig.resolve,
      alias: {
        ...customConfig.resolve.alias,
        vue$: config.resolve.alias.vue$
      }
    }
  }

  result.module.rules.push({
    test: /\.stories\.ts?$/,
    loaders: {
      loader: require.resolve('@storybook/addon-storysource/loader'),
      options: { parser: 'typescript' }
    },
    enforce: 'pre'
  })

  return result
}
