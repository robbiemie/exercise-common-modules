declare module '*.mp3'
