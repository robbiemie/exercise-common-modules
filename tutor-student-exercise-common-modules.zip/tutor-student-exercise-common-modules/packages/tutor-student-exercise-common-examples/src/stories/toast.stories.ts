import Vue from 'vue'
import { storiesOf } from '@storybook/vue'
import { number, text } from '@storybook/addon-knobs'
import Toast from '@tutor/student-exercise-common-test'
import '@tutor/student-exercise-common-test/dist/student-exercise-common-test.css'

Toast.install(Vue)
Vue.component('Toast', Toast.Toast)

const story = storiesOf(`toast`, module)
story.add('toast button', () => ({
    template: `
<div>
    <toast :text="text" :duration="duration" :isVisible.sync="isVisible"/>
    <button @click="showToastByComponent()">show toast by component</button>
    <button @click="showToastByApi(text, duration)">show toast by $toast</button>
</div>`,
    props: {
        duration: {
            default: number('duration', 1000)
        },
        text: {
            default: text('text', 'Toast 测试')
        },
        isVisible: false
    },
    methods: {
        showToastByApi(text, duration) {
            const vueInstance = new Vue()
            vueInstance.$toast.show(text, duration)
        },
        showToastByComponent() {
            // this.isVisible = true
        }
    },
    beforeDestroy() {
        const vueInstance = new Vue()
        vueInstance.$toast.hide()
    }
}))
