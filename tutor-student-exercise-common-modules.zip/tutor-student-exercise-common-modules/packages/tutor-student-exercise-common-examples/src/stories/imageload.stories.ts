import Vue from 'vue'
import { storiesOf } from '@storybook/vue'
import ImageLoad from '@tutor/student-exercise-common-image-load'
import '@tutor/student-exercise-common-image-load/dist/student-exercise-common-image-load.css'

import '../style/story.less'
Vue.component('ImageLoad', ImageLoad)
const story = storiesOf(`imageload`, module)
story.add('src type', () => ({
    template: `
    <div>
        <div class="section">
            <h2>string</h2>
            <ImageLoad
                class="image"
                :src="'https://yfd1.fbcontent.cn/s/logo-edb6dab9c4.png'"
                @loadSuccess="handleLoadSuccess"
                @loadFailed="handleLoadFailed"
            >
            </ImageLoad>
        </div>
        <div class="section">
            <h2>function</h2>
            <ImageLoad
                class="image"
                :src="urlFunction"
                @loadSuccess="handleLoadSuccess"
                @loadFailed="handleLoadFailed"
            >
            </ImageLoad>
        </div>
        <div class="section">
            <h2>promise</h2>
            <ImageLoad
                class="image"
                :src="urlPromise"
                @loadSuccess="handleLoadSuccess"
                @loadFailed="handleLoadFailed"
            >
            </ImageLoad>
        </div>
    </div>`,
    props: {},
    data: function() {
        return {
            urlPromise: new Promise(resolve => {
                setTimeout(() => {
                    resolve('https://yfd1.fbcontent.cn/s/logo-edb6dab9c4.png')
                }, 3000)
            }),
            urlFunction: () => {
                console.log('urlFuncion')
                return 'https://yfd1.fbcontent.cn/s/logo-edb6dab9c4.png'
            }
        }
    },
    methods: {
        handleLoadSuccess(e, img) {
            console.log('handleLoadSuccess', e, img)
        },
        handleLoadFailed(e) {
            console.log('handleLoadFailed', e)
        }
    },
    beforeDestroy() {}
}))
story.add('loadStatus', () => ({
    template: `
    <div>
        <div class="section">
            <h2>加载成功</h2>
            <ImageLoad
                class="image"
                :src="'https://yfd1.fbcontent.cn/s/logo-edb6dab9c4.png'"
                @loadSuccess="handleLoadSuccess"
                @loadFailed="handleLoadFailed"
            >
            </ImageLoad>
        </div>
        <div class="section">
            <h2>加载失败</h2>
            <ImageLoad
                class="image"
                :src="'https://yfd1.fbcontent.cn/s/logo-edb6dab9c45.png'"
                @loadSuccess="handleLoadSuccess"
                @loadFailed="handleLoadFailed"
            >
            </ImageLoad>
        </div>
    </div>`,
    props: {},
    data: function() {
        return {}
    },
    methods: {
        handleLoadSuccess(e, img) {
            console.log('handleLoadSuccess', e, img)
        },
        handleLoadFailed(e) {
            console.log('handleLoadFailed', e)
        }
    },
    beforeDestroy() {}
}))

story.add('fitStyle', () => ({
    template: `
    <div>
        <div class="section">
            <h2>none(default)</h2>
            <ImageLoad
                class="image"
                :src="'https://yfd1.fbcontent.cn/s/logo-edb6dab9c4.png'"
                @loadSuccess="handleLoadSuccess"
                @loadFailed="handleLoadFailed"
            >
            </ImageLoad>
        </div>
        <div class="section">
            <h2>fill</h2>
            <ImageLoad
                class="image"
                :src="'https://yfd1.fbcontent.cn/s/logo-edb6dab9c4.png'"
                :fit="'fill'"
                @loadSuccess="handleLoadSuccess"
                @loadFailed="handleLoadFailed"
            >
            </ImageLoad>
        </div>
        <div class="section">
            <h2>contain</h2>
            <ImageLoad
                class="image"
                :src="'https://yfd1.fbcontent.cn/s/logo-edb6dab9c4.png'"
                :fit="'contain'"
                @loadSuccess="handleLoadSuccess"
                @loadFailed="handleLoadFailed"
            >
            </ImageLoad>
        </div>
        <div class="section">
            <h2>cover</h2>
            <ImageLoad
                class="image"
                :src="'https://yfd1.fbcontent.cn/s/logo-edb6dab9c4.png'"
                :fit="'cover'"
                @loadSuccess="handleLoadSuccess"
                @loadFailed="handleLoadFailed"
            >
            </ImageLoad>
        </div>
        <div class="section">
            <h2>scale-down</h2>
            <ImageLoad
                class="image"
                :src="'https://yfd1.fbcontent.cn/s/logo-edb6dab9c4.png'"
                :fit="'scale-down'"
                @loadSuccess="handleLoadSuccess"
                @loadFailed="handleLoadFailed"
            >
            </ImageLoad>
        </div>
    </div>`,
    props: {},
    data: function() {
        return {}
    },
    methods: {
        handleLoadSuccess(e, img) {
            console.log('handleLoadSuccess', e, img)
        },
        handleLoadFailed(e) {
            console.log('handleLoadFailed', e)
        }
    },
    beforeDestroy() {}
}))

story.add('slot', () => ({
    template: `
    <div>
        <div class="section">
            <h2>placeholder</h2>
            <ImageLoad
                class="image"
                @loadSuccess="handleLoadSuccess"
                @loadFailed="handleLoadFailed"
            >
                <template v-slot:placeholder>
                    <div>PLACEHOLDER</div>
                </template>
            </ImageLoad>
        </div>
        <div class="section">
            <h2>error & loading</h2>
            <ImageLoad
                class="image"
                :src="'https://yfd1.fbcontent.cn/s/logo-edb6dab9c44.png'"
                ref="imageLoad"
                @loadSuccess="handleLoadSuccess"
                @loadFailed="handleLoadFailed"
            >
                <template v-slot:error>
                    <div class="btn" @click="$refs.imageLoad.handleImgReload">RETRY</div>
                </template>
                <template v-slot:loading>
                    <div>LOADING...</div>
                </template>
            </ImageLoad>
        </div>
    </div>`,
    props: {},
    data: function() {
        return {}
    },
    methods: {
        handleLoadSuccess(e, img) {
            console.log('handleLoadSuccess', e, img)
        },
        handleLoadFailed(e) {
            console.log('handleLoadFailed', e)
        }
    },
    beforeDestroy() {}
}))
