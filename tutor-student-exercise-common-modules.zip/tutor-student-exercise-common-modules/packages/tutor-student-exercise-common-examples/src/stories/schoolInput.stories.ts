import Vue from 'vue'
import { storiesOf } from '@storybook/vue'
import { SchoolInput, SchoolInputType } from '@tutor/student-exercise-common-school-input'
import '@tutor/student-exercise-common-school-input/dist/student-exercise-common-school-input.css'

Vue.component('SchoolInput', SchoolInput)

const demoSchoolData: SchoolInputType.School[] = [
    { id: 1024881, name: "北京小学" },
    { id: 1024505, name: "北京英国学校" },
    { id: 1024653, name: "北京进步小学" },
    { id: 1024665, name: "北京·通州·芙蓉小学" },
    { id: 1024663, name: "北京小学天宁寺分校" },
    { id: 1024893, name: "北京小学红山分校" },
    { id: 1024921, name: "北京十一丰台小学" },
    { id: 1025075, name: "北京小学大兴分校" },
    { id: 1025321, name: "北京小学走读部" },
    { id: 1025341, name: "北京小学分校" },
    { id: 1025329, name: "北京雷锋小学" },
    { id: 1025373, name: "北京小学通州分校" },
    { id: 1025965, name: "北京力学小学" },
    { id: 1027113, name: "北京新希望学校" },
    { id: 1026635, name: "北京朝阳外语小学" },
    { id: 1026789, name: "北京金海河学校" },
    { id: 1026897, name: "北京燕山向阳小学" },
    { id: 1027231, name: "北京群英希望小学" },
    { id: 1027323, name: "北京铁路实验小学" }
]

const story = storiesOf(`school`, module)
story.add('schoolinput', () => ({
    template: `
    <div id="app">
        <SchoolInput
            :value="curSchool"
            :getSchoolList="getSchoolList"
            @change="onChange"
        >
            <template v-slot:search-loading>
                <span>Loading……</span>
            </template>
        </SchoolInput>
    </div>`,
    props: {
    },
    data: function () {
        return {
            curSchool: { id: 1024881, name: "北京小学" }
        }
    },
    methods: {
        onChange(selectedSchool: SchoolInputType.School) {
            (this as any).curSchool = selectedSchool
        },
        filterSchoolList(keywords: string) {
            return demoSchoolData.filter(item => {
                return item.name.indexOf(keywords) >= 0
            })
        },
        async getSchoolList(keywords: string) {
            let schoolList: SchoolInputType.School[] = await new Promise((resolve, reject) => {
                setTimeout(() => {
                    const newSchoolList = (this as any).filterSchoolList(keywords)
                    resolve(newSchoolList)
                }, 1000)
            })
            return schoolList
        }
    },
    beforeDestroy() {
    }
}))
