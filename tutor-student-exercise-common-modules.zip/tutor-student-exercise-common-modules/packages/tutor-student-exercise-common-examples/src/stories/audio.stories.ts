import Vue from 'vue'
import { storiesOf } from '@storybook/vue'
import { number, text } from '@storybook/addon-knobs'
import Audio from '@tutor/student-exercise-common-audio'
import { VueClass } from 'vue-class-component/lib/declarations'

Vue.component('Toast', Audio)

const story = storiesOf(`audio`, module)
story.add('audio', () => ({
    template: `
    <div>
        <Audio ref="audio" :src="'https://tutor-test.fbcontent.cn/tutor-cyber-question-audio-test/15fe7bba23348b1/raw.mp3'" />
        <button @click="play()">play</button>
        <button @click="pause()">pause</button>
    </div>`,
    props: {
    },
    methods: {
        play() {
            const $audio = (this as any).$refs.audio
            $audio.play()
        },
        pause() {
            const $audio = (this as any).$refs.audio
            $audio.pause()
        }
    },
    beforeDestroy() {
        const vueInstance = new Vue()
        vueInstance.$toast.hide()
    }
}))
