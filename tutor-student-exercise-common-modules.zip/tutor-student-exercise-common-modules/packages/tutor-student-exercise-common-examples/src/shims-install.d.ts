import Vue from 'vue'

// declare module 'vue/types/vue' {
//     interface VueConstructor {
//         install: (Vue: VueConstructor) => void
//     }

//     interface Vue {
//         isvisible: boolean
//         loadingText: string
//     }

//     interface Vue {
//         toastText: string
//         duration: number
//         isVisible: boolean
//     }
// }
