/* eslint-disable @typescript-eslint/no-var-requires */
const path = require('path')
const BundleAnalyzerPlugin = require('webpack-bundle-analyzer').BundleAnalyzerPlugin

module.exports = {
    lintOnSave: false,
    parallel: false,
    publicPath: '',
    chainWebpack: config => {
        config.resolve.alias.delete('@')

        config.plugins.delete('preload')
        config.plugins.delete('prefetch')

        if (process.env.BUNDLE_ANALYZE) {
            config.plugin('bundle-analyzer').use(BundleAnalyzerPlugin)
        }
    }
}
