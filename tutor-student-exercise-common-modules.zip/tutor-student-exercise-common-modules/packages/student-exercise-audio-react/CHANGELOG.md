# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

### [0.0.3](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/compare/v0.1.15...v0.0.3) (2021-08-04)


### Features

* **examples:** add imageLoad.stories ([8c13d62](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/8c13d623370c0741457ec3b768bc3d837af73a00))
* **image-load:** add imageLoad component ([56bfe5c](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/56bfe5c8d293fdb9572ee610c2adbab08c8cea6b))
* **image-load:** add multiple src input type ([33cd35b](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/33cd35b9b9b3c533164f3a556b2a248063d3d0d9))

### [0.0.2](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/compare/v0.1.15...v0.0.2) (2021-08-03)


### Features

* **examples:** add imageLoad.stories ([8c13d62](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/8c13d623370c0741457ec3b768bc3d837af73a00))
* **image-load:** add imageLoad component ([56bfe5c](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/56bfe5c8d293fdb9572ee610c2adbab08c8cea6b))
* **image-load:** add multiple src input type ([33cd35b](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/33cd35b9b9b3c533164f3a556b2a248063d3d0d9))
