'use strict';

const studentExerciseAudioReact = require('..');

describe('@tutor/student-exercise-audio-react', () => {
    it('needs tests');
});
