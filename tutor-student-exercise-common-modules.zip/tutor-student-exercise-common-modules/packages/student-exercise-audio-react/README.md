# react 版 audio 组件

## Usage

```tsx
<AudioService
    ref={audioRef}
    src={audioSrc}
    onAudioStatusChange={updateAudioStatus}
    onAudioCurrentTime={updateAudioCurrentTime}
    onAudioDuringTime={updateAudioDuringTime}
    onAudioLoadStart={() => {
        handleAudioErrorToast()
        onAudioLoadStart && onAudioLoadStart()
    }}
    onAudioLoaded={() => {
        AudioPlayerService.clearLoadAudioTimer()
        onAudioLoaded && onAudioLoaded()
    }}
    onAudioCanPlay={(
        url: string,
        context?: AudioContext
    ) => {
        console.warn('audioPlayer 组件被执行', url)
        eventBus.emit(`AUDIO_LOADED_${url}`)
        if (
            useEngine &&
            !AudioPlayerService.URLCache.has(url)
        ) {
            AudioPlayerService.URLCache.set(url, {
                loaded: true,
                url,
                context,
            })
        }
        onAudioCanPlay && onAudioCanPlay(url)
    }}
    onAudioCanPlayThrough={() => {
        onAudioCanPlayThrough && onAudioCanPlayThrough()
    }}
    onAudioPlay={() => {
        onAudioPlay && onAudioPlay()
    }}
    onAudioPause={() => {
        onAudioPause && onAudioPause()
    }}
    onAudioEnd={() => {
        onAudioEnd && onAudioEnd()
    }}
    onAudioStop={() => {
        onAudioStop && onAudioStop()
    }}
    onAudioSeek={() => {
        onAudioSeek && onAudioSeek()
    }}
    onAudioError={err => {
        if (err?.type === 'onPlayError') {
            handleAudioErrorToast()
            playerDispatch(
                setPlayerStatus(PLAYER_STATUS.ERROR)
            )
        }
        onAudioError && onAudioError(err)
    }}
    onAudioVolumnChange={(volume: number) => {
        onAudioVolumnChange && onAudioVolumnChange(volume)
    }}
    onAudioPlayRate={(duringTime: number) => {
        onAudioPlayRate && onAudioPlayRate(duringTime)
    }}
/>
```
