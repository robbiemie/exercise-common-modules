export type ErrorData = {
    useEngine: boolean
    error: string
    type: string
}
