export enum AUDIO_EMIT_EVENT {
    'AUDIOPAUSE' = 'onAudioPause',
    'AUDIOLOAD' = 'onAudioLoad',
    'AUDIOLOADERROR' = 'onAudioLoadError',
    'AUDIOPLAY' = 'onAudioPlay',
    'AUDIOPLAYERROR' = 'onAudioPlayError',
    'AUDIOEND' = 'onAudioEnd',
    'AUDIOSTOP' = 'onAudioStop',
}

export enum AUDIO_STATUS {
    'idle' = 'idle',
    'loading' = 'loading',
    'loaded' = 'loaded',
    'readyPlay' = 'readyPlay',
    'playing' = 'playing',
    'paused' = 'paused',
    'ended' = 'ended',
    'error' = 'error',
}
