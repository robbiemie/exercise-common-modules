import AudioService from './service/AudioService'

export default AudioService
