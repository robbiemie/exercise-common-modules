import {
    AudioContext,
    BridgeProto,
    BridgeProtoManager,
    container,
    WebProtoData,
} from '@tutor/box-bridge-ts'
import { CompatibilityHelper } from '../common/CompatibilityHelper'

const bridgeProtoManager: BridgeProtoManager = container.resolve(
    BridgeProtoManager
)
interface URLCachePayload {
    loaded: boolean
    url: string
    context?: AudioContext | null
}
export default class AudioPlayerService {
    // 缓存音频 URL
    public static URLCache: Map<string, URLCachePayload> = new Map()

    public static AudioDuringTimeMap: Map<string, number> = new Map()

    public static LoadAudioTimer: any = null

    public static useEngine = CompatibilityHelper.isSupportAudioEngineComponent

    /**
     * 获取音频时长
     * @param url
     */
    public static getAudioDuringTime(url: string): number {
        if (!url) return 0
        return this.AudioDuringTimeMap.get(url) || 0
    }

    /**
     * 设置音频时长
     * @param url
     * @param time
     */
    public static setAudioDuringTime(url: string, time: number = 0) {
        if (url) {
            this.AudioDuringTimeMap.set(url, time)
        }
    }

    /**
     *
     * @param callback 回调函数
     * @param delay 超时时间（单位:s）
     */
    public static startLoadAudio(callback?: () => void, delay = 10) {
        const startTime = Date.now()
        this.LoadAudioTimer = setInterval(() => {
            const interval = Date.now() - startTime
            if (interval > delay * 1000) {
                // 12s 后自动弹toast
                callback && callback()
                this.clearLoadAudioTimer()
            }
        }, 1000)
    }

    public static clearLoadAudioTimer() {
        if (this.LoadAudioTimer) {
            clearInterval(this.LoadAudioTimer)
            this.LoadAudioTimer = null
        }
    }

    static async getAudioSrc(url: string) {
        let audioUrl = url
        const fileUrl = await this.getFileUrl({
            url,
            uniqueId: url,
        })
        if (fileUrl) {
            audioUrl = fileUrl
        }
        return audioUrl
    }

    static async getFileUrl(downloadFile: BridgeProto.IWDownloadFile) {
        try {
            const result = await bridgeProtoManager.sendProto(
                WebProtoData.TypeCode.WDownloadFile,
                data => {
                    Object.assign(data, downloadFile)
                },
                12000
            ) // 12s
            return result.fileURI
        } catch (e) {
            console.error(e)
        }
    }

    /**
     * 加载音频资源
     * @param url
     */
    static async handleLoadAudio(url: string) {
        if (!url) return
        let audioUrl = url
        if (this.useEngine) {
            // 读取客户端本地 url
            audioUrl = await AudioPlayerService.getAudioSrc(audioUrl)
        }
        return audioUrl
    }
}
