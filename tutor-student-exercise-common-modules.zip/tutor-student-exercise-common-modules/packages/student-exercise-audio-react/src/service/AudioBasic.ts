import {
    AudioContext,
    BaseAudioService,
    UIManager,
    container,
} from '@tutor/box-bridge-ts'
import { sleep } from '../common/util'
import EventBus from '../common/EventBus'
import { AUDIO_EMIT_EVENT } from '../constants/Audio'

const Logger = console
export const AudioEngineContext = AudioContext

export interface AudioEmitService extends AudioContext {
    id?: number
    on: (...args: any[]) => any
    off: (...args: any[]) => any
    emit: (...args: any[]) => any
    once: (...args: any[]) => any
    destroy: (soundId?: number) => any
}

export default class AudioBase extends BaseAudioService {
    private cachedAudioEmit: Map<string, EventBus> = new Map()

    async loadAudios(urls: string[], untilLoaded: boolean = false) {
        urls.forEach(async url => {
            await this.loadAudioExtend(url, untilLoaded, true)
            const audio = this.getAudioContext(url)
            if (audio) {
                audio.once(
                    [
                        AUDIO_EMIT_EVENT.AUDIOLOADERROR,
                        AUDIO_EMIT_EVENT.AUDIOPLAYERROR,
                    ],
                    () => {
                        audio.destroy()
                    }
                )
            }
            await sleep(100)
        })
    }

    async loadAudioExtend(
        url: string,
        untilLoaded: boolean = false,
        ignoreToast: boolean = false
    ): Promise<AudioContext> {
        const bus: EventBus = this.cachedAudioEmit.get(url) || new EventBus()
        const audioCallbacks = {
            onLoad: () => {
                bus.emit(AUDIO_EMIT_EVENT.AUDIOLOAD, {
                    url,
                })
            },
            onLoadError: (err: any) => {
                Logger.error(`${url} load error, err=${err}`)
                bus.emit(AUDIO_EMIT_EVENT.AUDIOLOADERROR, {
                    url,
                })
                if (!ignoreToast) {
                    const uiManager: UIManager = container.resolve(UIManager)
                    uiManager.toast('音频加载失败')
                }
            },
            onPlay: () => {
                Logger.log(`${url} play`)
                bus.emit(AUDIO_EMIT_EVENT.AUDIOPLAY, {
                    url,
                })
            },
            onPlayError: () => {
                Logger.error(`${url} playerror`)
                bus.emit(AUDIO_EMIT_EVENT.AUDIOPLAYERROR, {
                    url,
                })
            },
            onPause: () => {
                Logger.log(`${url} pause`)
                bus.emit(AUDIO_EMIT_EVENT.AUDIOPAUSE, {
                    url,
                })
            },
            onStop: () => {
                Logger.log(`${url} stop`)
                bus.emit(AUDIO_EMIT_EVENT.AUDIOSTOP, {
                    url,
                })
            },
            onEnd: () => {
                Logger.log(`${url} end`)
                bus.emit(AUDIO_EMIT_EVENT.AUDIOEND, {
                    url,
                })
            },
        }
        this.cachedAudioEmit.set(url, bus)

        return this.loadAudio(url, untilLoaded, audioCallbacks)
    }

    getAudioContext(url: string): AudioEmitService | undefined {
        const context = super.getAudioContext(url)
        const bus: EventBus | undefined = this.cachedAudioEmit.get(url)
        if (bus && context) {
            return Object.assign(context, {
                on: bus.on.bind(bus),
                emit: bus!.emit.bind(bus),
                off: bus!.off.bind(bus),
                once: bus!.once.bind(bus),
                destroy: () => {
                    this.destroyContext(url)
                },
            })
        }
        return undefined
    }

    async destroyContext(url: string) {
        this.cachedAudioEmit.delete(url)
        await this.destroyAudio(url)
    }
}
export const audioBase = new AudioBase()
