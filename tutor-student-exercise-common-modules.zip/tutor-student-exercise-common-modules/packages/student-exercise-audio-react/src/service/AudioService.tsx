import React, {
    useState,
    useEffect,
    useRef,
    forwardRef,
    useImperativeHandle,
} from 'react'
import { AudioContext } from '@tutor/box-bridge-ts'
import { AUDIO_STATUS } from '../constants/Audio'
import { CompatibilityHelper } from '../common/CompatibilityHelper'
import AudioPlayerService from './AudioPlayerService'
import { ErrorData } from '../types/Audio'

import { audioBase as audioService } from './AudioBasic'

type AudioFunctionType = () => any
export interface AudioRefInterface {
    audioStatus: AUDIO_STATUS
    /**
     * 播放当前音频文件
     * @param from 从头播放/从当前位置播放
     */
    play: (from?: string) => Promise<void>
    /**
     * 播放指定音频
     * @param url 预播放音频地址
     */
    playFromUrl: (url: string) => Promise<void> | undefined
    pause: AudioFunctionType
    stop: AudioFunctionType
    destroy: AudioFunctionType
    /**
     * 设置音频播放进度
     */
    seek: (targetTime: number) => void
    setVolume: (volume: number) => void
    setSpeed: (playbackRate: number) => void
}
export interface AudioServiceProps {
    autoPlay?: boolean // 自动播放
    loop?: boolean // 循环播放
    muted?: boolean // 静音
    volume?: number // 音量
    src: string // 音频地址
    /**
     * 音频资源加载完成回调
     */
    onAudioLoadStart?: () => void
    onAudioLoaded?: () => void
    onAudioCanPlay?: (url: string, context: AudioContext | null) => void
    onAudioCanPlayThrough?: () => void
    onAudioPlay?: () => void
    onAudioPause?: () => void
    onAudioEnd?: () => void
    onAudioStop?: () => void
    onAudioSeek?: () => void
    onAudioError?: (data: ErrorData) => void
    onAudioVolumnChange?: (volume: number) => void
    onAudioStatusChange?: (audioStatus: AUDIO_STATUS) => void
    onAudioCurrentTime?: (currentTime: number) => void
    onAudioDuringTime?: (duringTime: number) => void
    onAudioPlayRate?: (duringTime: number) => void
}
const AudioService = (props: AudioServiceProps, ref: any) => {
    const {
        autoPlay,
        loop,
        muted,
        src,
        onAudioLoadStart,
        onAudioLoaded,
        onAudioCanPlay,
        onAudioCanPlayThrough,
        onAudioPlay,
        onAudioPause,
        onAudioEnd,
        onAudioStop,
        onAudioSeek,
        onAudioError,
        onAudioVolumnChange,
        onAudioStatusChange,
        onAudioCurrentTime,
        onAudioDuringTime,
        onAudioPlayRate,
    } = props
    // 是否端内使用 audio engine
    const useEngine = CompatibilityHelper.isSupportAudioEngineComponent
    const audioStatusRef = useRef<AUDIO_STATUS>(AUDIO_STATUS.idle)
    // 音频总时长
    const [, setAudioDuration] = useState(0)
    // 音频音量
    const [, setAudioVolume] = useState(0.5)
    // 播放语速
    const [, setAudioPlaybackRate] = useState(1)
    const [audioHtmlContext, setAudioHtmlContext] = useState<any>(null)
    const audioEngineContextRef = useRef<AudioContext | null>(null)
    const timerRef = useRef<any>(null) // fix bug: 不能定义一个普通变量存储 timer
    const audioRef = useRef<null | HTMLMediaElement>(null)
    useEffect(() => {
        return () => {
            updateAudioCurrentTime(0)
            if (timerRef.current) {
                clearTimeout(timerRef.current)
                timerRef.current = null
            }
        }
    }, [])
    useEffect(() => {
        initAudio()
    }, [src])

    useImperativeHandle(
        ref,
        (): AudioRefInterface => ({
            audioStatus: audioStatusRef.current,
            play,
            playFromUrl, // 播放另一个已加载的音频
            pause,
            stop,
            destroy,
            seek,
            setVolume,
            setSpeed,
        })
    )
    const initAudio = () => {
        if (!src) return

        !useEngine &&
            audioRef.current?.addEventListener(
                'canplay',
                () => {
                    // fix bug: H5 设置 currentTime 会重新触发
                    // https://segmentfault.com/a/1190000016409976
                    handleAudioCanPlay(src)
                },
                {
                    once: true,
                }
            )
        const result = AudioPlayerService.URLCache.get(src)
        if (result?.context) {
            audioEngineContextRef.current = result.context
            // 不重复加载 contexxt
            if (onAudioCanPlay) {
                onAudioCanPlay(src, getAudioContext(src))
            }

            return
        }

        // IOS
        // fixbug: The preload attribute is supported in Safari 5.0 and later. Safari on iOS never preloads.
        handleLoadAudio(autoPlay)
    }
    const updateAudioCurrentTime = (time: number) => {
        if (onAudioCurrentTime) {
            onAudioCurrentTime(time)
        }
    }
    const updateAudioStatusChange = (status: AUDIO_STATUS) => {
        audioStatusRef.current = status
        console.log('audio status: ', status)
        if (onAudioStatusChange) {
            onAudioStatusChange(status)
        }
        if (status === AUDIO_STATUS.playing) {
            refreshProgress()
        }
    }
    const getAudioContext = (url: string): AudioContext | null => {
        const result = AudioPlayerService.URLCache.get(url)
        if (result?.context) {
            return result.context
        }
        return audioEngineContextRef.current
    }
    /**
     * 加载音频
     */
    const handleLoadAudio = async (autoplay: boolean = false) => {
        updateAudioStatusChange(AUDIO_STATUS.loading)
        if (useEngine) {
            // 初始化 audio engine
            await loadEngineAudio(autoplay)
        } else {
            const audioEl = audioRef.current
            audioEl?.load()
        }
    }
    const play = async (from = 'continue') => {
        // 播放audio
        if (useEngine) {
            if (audioStatusRef.current === AUDIO_STATUS.error) {
                // 异常逻辑，音频加载重试
                updateAudioStatusChange(AUDIO_STATUS.idle)
                if (useEngine) {
                    // 自动播放音频
                    handleLoadAudio(true)
                }
            }
            if (from === 'continue') {
                return getAudioContext(src)?.playContinued()
            }
            if (from === 'start') {
                return getAudioContext(src)?.playFromStart()
            }
        } else {
            const audioEl = audioRef.current as HTMLMediaElement
            // 注意：chrome 禁止自动播放音频
            return audioEl?.play()
        }
    }
    /**
     *
     * @param url 通过url播放已加载音频
     * @returns
     */
    const playFromUrl = (url: string) => {
        // 播放audio
        if (useEngine) {
            audioService.playAudio(url)
        } else {
            const audioEl = audioRef.current as HTMLMediaElement
            // 注意：chrome 禁止自动播放音频
            return audioEl?.play()
        }
    }
    const pause = () => {
        // 暂停audio
        if (useEngine) {
            return getAudioContext(src)?.pause()
        }
        const audioEl = audioRef.current as HTMLMediaElement
        return audioEl?.pause()
    }
    const stop = () => {
        // 暂停audio
        if (useEngine) {
            getAudioContext(src)?.stop()
        }
        if (audioHtmlContext) {
            audioHtmlContext!.pause()
            audioHtmlContext!.currentTime = 0
        }
        updateAudioCurrentTime(0)
    }

    const destroy = () => {
        // 销毁引擎
        if (useEngine) {
            getAudioContext(src)?.destroy()
        }
    }
    const seek = (targetTime: number) => {
        // 跳转到对应位置
        if (useEngine) {
            const intTime = parseInt(`${targetTime * 1000}`, 10)
            getAudioContext(src)?.seek(intTime)
        } else if (audioHtmlContext) {
            audioHtmlContext.currentTime = targetTime
        }
        updateAudioCurrentTime(targetTime)
    }
    const setVolume = (volume: number) => {
        // 设置音量
        if (useEngine) {
            getAudioContext(src)?.setAudioVolume(volume)
        } else if (audioHtmlContext) {
            audioHtmlContext.volume = volume
        }
        onAudioVolumnChange && onAudioVolumnChange(volume)
        setAudioVolume(volume)
    }
    const setSpeed = (playbackRate: number) => {
        // 设置播放语速
        if (useEngine) {
            getAudioContext(src)?.setAudioSpeed(playbackRate)
        } else if (audioHtmlContext) {
            audioHtmlContext!.playbackRate = playbackRate
        }
        setAudioPlaybackRate(playbackRate)
        if (onAudioPlayRate) {
            onAudioPlayRate(playbackRate)
        }
    }
    const handleError = (error: {
        type: string
        useEngine: boolean
        error: any
    }) => {
        onAudioError && onAudioError(error)
        console.error('handleError', error)
    }
    /**
     * 初始化引擎
     */
    const loadEngineAudio = async (autoplay: boolean = false) => {
        if (!src) return
        const aeContext = await audioService.loadAudio(
            src,
            false,
            {
                onLoad(url) {
                    const duringTime =
                        (getAudioContext(url)?.audioDuration || 0) / 1000
                    setAudioDuration(duringTime)
                    onAudioDuringTime && onAudioDuringTime(duringTime)
                    updateAudioStatusChange(AUDIO_STATUS.readyPlay)
                    // console.log('音频 onLoaded')
                    if (onAudioLoaded) {
                        onAudioLoaded()
                    }
                    /** 如果不触发play audioEngineContextRef.current中没有soundId对象，这样假如直接seek，导致没有意义，还会重头播放
                     *  直接play() 和 pause() 会生成soundId
                     */
                    try {
                        play()
                        pause()
                        // console.warn('音频 onCanPlay')
                        if (onAudioCanPlay) {
                            onAudioCanPlay(url, getAudioContext(url))
                            if (autoplay) {
                                play('start')
                            }
                        }
                        // console.log('音频 onCanPlayThrough')
                        if (onAudioCanPlayThrough) {
                            onAudioCanPlayThrough()
                        }
                    } catch (e) {
                        console.error(e)
                    }
                },
                onPlay(url) {
                    updateAudioStatusChange(AUDIO_STATUS.playing)
                    // console.log('音频 onPlay')
                    if (onAudioPlay) {
                        onAudioPlay()
                    }
                },
                onPause(url) {
                    updateAudioStatusChange(AUDIO_STATUS.paused)
                    // console.log('音频 onPause')
                    if (onAudioPause) {
                        onAudioPause()
                    }
                },
                onEnd(url) {
                    updateAudioStatusChange(AUDIO_STATUS.ended)
                    if (onAudioEnd) {
                        onAudioEnd()
                    }
                },
                onStop(url) {
                    updateAudioStatusChange(AUDIO_STATUS.paused)
                    updateAudioCurrentTime(0)
                    // console.log('音频 onStop')
                    if (onAudioStop) {
                        onAudioStop()
                    }
                },
                onSeek(url) {
                    // console.log('音频 onSeek')
                    if (onAudioSeek) {
                        onAudioSeek()
                    }
                },
                onLoadError(err, url) {
                    updateAudioStatusChange(AUDIO_STATUS.error)
                    if (onAudioError) {
                        handleError({
                            useEngine: true,
                            error: err,
                            type: 'onLoadError',
                        })
                    }
                },
                onSeekError(err, url) {
                    updateAudioStatusChange(AUDIO_STATUS.error)
                    if (onAudioError) {
                        handleError({
                            useEngine: true,
                            error: err,
                            type: 'onSeekError',
                        })
                    }
                },
                onPlayError(err, url) {
                    updateAudioStatusChange(AUDIO_STATUS.error)
                    if (onAudioError) {
                        handleError({
                            useEngine: true,
                            error: err,
                            type: 'onPlayError',
                        })
                    }
                },
                onVolumeChangeError(err, url) {
                    updateAudioStatusChange(AUDIO_STATUS.error)
                    if (onAudioError) {
                        handleError({
                            useEngine: true,
                            error: err,
                            type: 'onVolumeChangeError',
                        })
                    }
                },
                onSpeedChangeError(err, url) {
                    updateAudioStatusChange(AUDIO_STATUS.error)
                    if (onAudioError) {
                        handleError({
                            useEngine: true,
                            error: err,
                            type: 'onSpeedChangeError',
                        })
                    }
                },
            },
            loop
        )

        audioEngineContextRef.current = aeContext
        if (onAudioLoadStart) {
            onAudioLoadStart()
        }
    }
    /**
     * 音频开始加载
     */
    const onHtmlAudioLoadStart = () => {
        updateAudioStatusChange(AUDIO_STATUS.loading)
        if (onAudioLoadStart) {
            onAudioLoadStart()
        }
    }
    /**
     * 资源加载完成
     */
    const onHtmlAudioLoadedMetaData = () => {
        const audioEl = audioRef.current as HTMLMediaElement
        const duringTime = audioEl?.duration || 0
        setAudioDuration(duringTime)

        onAudioDuringTime && onAudioDuringTime(duringTime)
        setAudioVolume(audioEl?.volume || 0.5)
        setAudioHtmlContext(audioEl)
        if (onAudioLoaded) {
            onAudioLoaded()
        }
    }
    const onHtmlAudioCanPlay = (url: string) => {
        updateAudioStatusChange(AUDIO_STATUS.readyPlay)
        if (onAudioCanPlay) {
            onAudioCanPlay(url, null)
        }
    }
    const onHtmlAudioCanPlayThrough = () => {
        if (onAudioCanPlayThrough) {
            onAudioCanPlayThrough()
        }
    }
    const onHtmlAudioPlay = () => {
        if (onAudioPlay) {
            onAudioPlay()
        }
    }
    const onHtmlAudioPlaying = () => {
        updateAudioStatusChange(AUDIO_STATUS.playing)
    }
    const onHtmlAudioSeeked = () => {
        if (onAudioSeek) {
            onAudioSeek()
        }
    }
    const onHtmlAuidoSeeking = () => {
        updateAudioStatusChange(AUDIO_STATUS.playing)
    }
    const onHtmlAudioPause = () => {
        updateAudioStatusChange(AUDIO_STATUS.paused)
        if (onAudioPause) {
            onAudioPause()
        }
    }
    const onHtmlAudioEnded = () => {
        updateAudioStatusChange(AUDIO_STATUS.ended)
        if (onAudioEnd) {
            onAudioEnd()
        }
    }
    const onHtmlAudioError = (error: any) => {
        updateAudioStatusChange(AUDIO_STATUS.error)
        if (onAudioError) {
            handleError({
                useEngine: false,
                error,
                type: 'onHtmlAudioError',
            })
        }
    }
    const refreshProgress = () => {
        if (audioStatusRef.current === AUDIO_STATUS.playing) {
            if (timerRef.current) {
                clearTimeout(timerRef.current)
                timerRef.current = null
            }
            // 定时刷新 currentTime
            timerRef.current = setTimeout(async () => {
                let currentTime = 0
                if (useEngine) {
                    currentTime =
                        ((await getAudioContext(src)?.getAudioCurrentTime()) ||
                            0) / 1000
                } else {
                    currentTime = audioHtmlContext?.currentTime || 0
                }
                // 更新 currentTime
                updateAudioCurrentTime(currentTime)
                refreshProgress()
            }, 150)
        } else {
            clearTimeout(timerRef.current)
            timerRef.current = null
        }
    }
    const handleAudioCanPlay = (url: string) => {
        if (onHtmlAudioCanPlay) {
            onHtmlAudioCanPlay(url)
        }
    }
    return (
        <>
            {!useEngine && src ? (
                <audio
                    className="audio_media_elem"
                    preload="auto"
                    controls={false}
                    ref={audioRef}
                    autoPlay={autoPlay}
                    loop={loop}
                    muted={muted}
                    src={src}
                    onLoadStart={onHtmlAudioLoadStart}
                    onLoadedMetadata={onHtmlAudioLoadedMetaData}
                    onPlay={onHtmlAudioPlay}
                    onPlaying={onHtmlAudioPlaying}
                    onSeeked={onHtmlAudioSeeked}
                    onSeeking={onHtmlAuidoSeeking}
                    onPause={onHtmlAudioPause}
                    onCanPlayThrough={onHtmlAudioCanPlayThrough}
                    onEnded={onHtmlAudioEnded}
                    onAbort={onHtmlAudioError}
                    onError={onHtmlAudioError}
                >
                    <track kind="captions" srcLang="en" />
                    暂不支持播放音频文件
                </audio>
            ) : null}
        </>
    )
}

export default forwardRef(AudioService)
