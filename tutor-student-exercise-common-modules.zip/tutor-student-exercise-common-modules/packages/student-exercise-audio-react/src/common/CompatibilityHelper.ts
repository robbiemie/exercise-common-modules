import { BridgeProtoManager, container } from '@tutor/box-bridge-ts'
import { isInnerApp, versionCompare } from '../common/util'

const bridgeProtoManager = container.resolve(BridgeProtoManager)

export class CompatibilityHelper {
    static isSupportAudioEngineComponent: boolean = false

    /**
     * 初始化
     */
    public static async init() {
        this.isSupportAudioEngineComponent = await this.getSupportAudioEngineComponent()
    }

    /**
     * 是否支持引擎
     */
    private static async getSupportAudioEngineComponent() {
        if (isInnerApp) {
            const protoVersion =
                (await bridgeProtoManager.getNativeProtoVersion()) || '0'
            return versionCompare(protoVersion, '1.11.24') > -1
        }
        return false
    }
}

export default CompatibilityHelper
