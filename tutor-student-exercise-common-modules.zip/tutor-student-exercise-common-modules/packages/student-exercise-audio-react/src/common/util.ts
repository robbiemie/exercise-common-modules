export const sleep = (delayTime: number) => {
    return new Promise(resolve => setTimeout(resolve, delayTime)).catch(() => {
        throw new Error('sleep catch error: ')
    })
}

export const isInnerApp = /YuanTiKu|YuanSouTi|YuanFuDao/.test(
    navigator.userAgent
)

export function versionCompare(v1: string, v2: string) {
    const v1Arr = v1.split('.')
    const v2Arr = v2.split('.')
    const v1Len = v1Arr.length
    let i = 0

    for (; i < v1Len; i += 1) {
        if (v1Arr[i] !== v2Arr[i]) {
            return Number.parseInt(v1Arr[i] || '0', 10) >
                Number.parseInt(v2Arr[i] || '0', 10)
                ? 1
                : -1
        }
    }
    return 0
}
