export default class EventBus {
    events: any

    constructor() {
        this.events = Object.create(null)
    }

    on(eventName: string, handler: (args?: any) => void) {
        if (!this.events[eventName]) {
            this.events[eventName] = []
        }
        this.events[eventName].push(handler)
    }

    once(eventName: string, handler: (args?: any) => void) {
        // eslint-disable-next-line no-param-reassign
        handler.prototype.once = true
        this.on(eventName, handler)
    }

    off(eventName: string, handler: () => void) {
        if (!this.events[eventName]) return
        const handlerIndex = this.events[eventName].findIndex(
            (fn: () => void) => fn === handler
        )
        this.events[eventName].splice(handlerIndex, 1)
        if (this.events[eventName].length === 0) {
            delete this.events[eventName]
        }
    }

    emit(eventName: string, ...args: any[]) {
        if (!this.events[eventName]) return
        this.events[eventName].forEach((handler: (args?: any) => void) => {
            handler(...args)
            if (handler.prototype.once) {
                this.off(eventName, handler)
            }
        })
    }
}

export const eventBus = new EventBus()
