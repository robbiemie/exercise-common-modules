
import Audio from './main.vue'
import { VueConstructor } from 'vue'

Audio.install = (Vue: VueConstructor) => {
    Vue.component('Audio', Audio)
}

export default Audio
