<template>
    <audio
        :src="src"
        :autoplay="autoPlay"
        ref="audio"
        class="audio-item"
        preload="auto"
        @loadedmetadata="onHtmlAudioLoadedMetaData"
        @loadstart="onHtmlAudioLoadStart"
        @play="onHtmlAudioPlay"
        @playing="onHtmlAudioPlaying"
        @seeked="onHtmlAudioSeeked"
        @seeking="onHtmlAuidoSeeking"
        @pause="onHtmlAudioPause"
        @canplay="onHtmlAudioCanPlay"
        @canplaythrough="onHtmlAudioCanPlayThrough"
        @ended="onHtmlAudioEnded"
        @abort="onHtmlAudioError"
        @error="onHtmlAudioError"
        v-if="!useEngine"
    ></audio>
</template>
<script lang='ts'>
enum AudioStatus {
    None = 'none',
    Loading = 'loading',
    Ready = 'ready',
    Playing = 'playing',
    Paused = 'paused',
    Ended = 'ended',
    Error = 'error'
}
import { Component, Prop, Vue, Watch } from 'vue-property-decorator'
import { AudioContext, BaseAudioService } from '@tutor/box-bridge-ts'

class AudioService extends BaseAudioService {

}

@Component
class Audio extends Vue {
    @Prop({ default: '' }) readonly src!: string
    @Prop({ default: false }) readonly useEngine!: boolean

    private audioStatus: AudioStatus = AudioStatus.None
    private audioDuration: number = 0
    private audioCurrentTime: number = 0
    private audioVolume: number = 1
    private autoPlay: boolean = false
    private audioHtmlContext?: HTMLMediaElement
    private audioEngineContext?: AudioContext
    private audioPlaybackRate: number = 1.0

    // 计算属性，外部只读
    get status() {
        return this.audioStatus
    }
    get duration() {
        return this.audioDuration
    }
    get currentTime() {
        return this.audioCurrentTime
    }
    get volume() {
        return this.audioVolume
    }
    get playbackRate() {
        return this.audioPlaybackRate
    }

    @Watch('audioStatus')
    onPlayStatusChange() {
        if(this.audioStatus === AudioStatus.Playing){
            this.refreshPosition()
        }
    }
    created() {
        console.log('useEngine', this.useEngine)
    }
    mounted() {
        this.load()
    }
    load() {
        if(this.useEngine){
            this.loadEngineAudio()
        }else{
            const $audio = this.$refs.audio as HTMLMediaElement
            $audio.load()
        }
    }
    play() {
        // 播放audio
        if(this.useEngine){
            // if (this.audioEnded) {
            //     this.audioContext.playFromStart()
            // } else {
            if(this.status === AudioStatus.Error){
                throw new Error('AudioPlayer playfailed')
            }else{
                return this.audioEngineContext?.playContinued()
            }
            // }
        }else{
            const $audio = this.$refs.audio as HTMLMediaElement
            return $audio.play()
        }
    }
    pause() {
        // 暂停audio
        if(this.useEngine){
            return this.audioEngineContext?.pause()
        }else{
            const $audio = this.$refs.audio as HTMLMediaElement
            return $audio.pause()
        }
    }
    stop() {
        // 暂停audio
        if(this.useEngine){
            this.audioEngineContext?.stop()
        }else{
            if(this.audioHtmlContext){
                this.audioHtmlContext!.pause()
                this.audioHtmlContext!.currentTime = 0
            }
        }
        this.audioCurrentTime = 0
    }
    destroy() {
        // 销毁引擎
        if(this.useEngine){
            this.audioEngineContext?.destroy()
        }
    }
    seek(targetTime: number) {
        // 跳转到对应位置
        if(this.useEngine){
            console.log(`call audio seek, targetTime=${targetTime}`)
            const intTime = parseInt(`${targetTime*1000}`, 10)
            this.audioEngineContext?.seek(intTime)
        }else{
            if(this.audioHtmlContext){
                this.audioHtmlContext!.currentTime = targetTime
            }
        }
        this.audioCurrentTime = targetTime
    }
    setVolume(volume: number) {
        // 设置音量
        if(this.useEngine){
            this.audioEngineContext?.setAudioVolume(volume)
        }else{
            if(this.audioHtmlContext){
                this.audioHtmlContext!.volume = volume
            }
        }
        this.audioVolume = volume
    }
    setSpeed(playbackRate: number) {
        // 设置播放语速
        if(this.useEngine){
            this.audioEngineContext?.setAudioSpeed(playbackRate)
        }else{
            if(this.audioHtmlContext){
                this.audioHtmlContext!.playbackRate = playbackRate
            }
        }
        this.audioPlaybackRate = playbackRate
    }
    // html audio相关
    onHtmlAudioLoadStart() {
        console.log('onHtmlAudioLoadStart')
        this.audioStatus = AudioStatus.Loading
        this.$emit('onLoadStart')
    }
    onHtmlAudioCanPlay() {
        console.log('onHtmlAudioCanPlay')
        this.audioStatus = AudioStatus.Ready
        this.$emit('onCanPlay')
    }
    onHtmlAudioCanPlayThrough() {
        console.log('onHtmlAudioCanPlayThrough')
        this.$emit('onCanPlayThrough')
    }
    onHtmlAudioPlay() {
        console.log('onHtmlAudioPlay')
        this.$emit('onPlay')
    }
    onHtmlAudioPause() {
        console.log('onHtmlAudioPause')
        this.audioStatus = AudioStatus.Paused
        this.$emit('onPause')
    }
    onHtmlAudioEnded() {
        console.log('onHtmlAudioEnded')
        this.audioStatus = AudioStatus.Ended
        this.$emit('onEnd')
    }
    onHtmlAudioSeeked() {
        console.log('onHtmlAudioSeeked')
        this.$emit('onSeek')
    }
    onHtmlAuidoSeeking() {
        console.log('onHtmlAuidoSeeking')
    }
    onHtmlAudioPlaying() {
        console.log('onHtmlAudioPlaying')
        this.audioStatus = AudioStatus.Playing
    }
    onHtmlAudioError(e: Event) {
        console.log('onHtmlAudioError')
        this.audioStatus = AudioStatus.Error
        this.$emit('onError', {useEngine: false, error: e})
    }
    onHtmlAudioLoadedMetaData() {
        const $audio = this.$refs.audio as HTMLMediaElement
        this.audioDuration = $audio.duration
        this.audioVolume = $audio.volume
        this.audioHtmlContext = $audio
        this.$emit('onLoad')
    }
    refreshPosition(){
        // 刷新currentTime
        if(this.audioStatus === AudioStatus.Playing){
            setTimeout(async () => {
                if(this.useEngine){
                    this.audioCurrentTime = (await this.audioEngineContext?.getAudioCurrentTime() || 0) / 1000
                }else{
                    this.audioCurrentTime = this.audioHtmlContext?.currentTime || 0
                }
                this.refreshPosition()
            }, 150)
        }
    }
    // 引擎相关
    private async loadEngineAudio(){
        const audioUrl = this.src
        const that = this
        const audioService = new AudioService()
        this.audioEngineContext = await audioService.loadAudio(audioUrl, false, {
            onLoad(url) {
                console.log(`audio loaded, url=${url}`)
                that.audioDuration = (that.audioEngineContext?.audioDuration || 0) / 1000
                that.audioStatus = AudioStatus.Ready
                that.$emit('onLoad')
                /** 如果不触发play audioEngineContext中没有soundId对象，这样假如直接seek，导致没有意义，还会重头播放
                 *  直接play() 和 pause() 会生成soundId
                 */
                try{
                    that.play()
                    that.pause()
                    that.$emit('onCanPlay')
                    that.$emit('onCanPlayThrough')
                }catch(e){
                    console.log('audio init load play error')
                }
            },
            onPlay(url) {
                console.log(`audio played, url=${url}`)
                that.audioStatus = AudioStatus.Playing
                that.$emit('onPlay')
            },
            onPause(url) {
                console.log(`audio paused, url=${url}`)
                that.audioStatus = AudioStatus.Paused
                that.$emit('onPause')
            },
            onEnd(url) {
                console.log(`audio ended, url=${url}`)
                that.audioStatus = AudioStatus.Ended
                that.$emit('onEnd')
            },
            onStop(url) {
                // pause + seek(0)
                console.log(`audio stopped, url=${url}`)
                that.audioStatus = AudioStatus.Paused
                that.audioCurrentTime = 0
                that.$emit('onStop')
            },
            onSeek(url) {
                console.log(`audio seeked, url=${url}`)
                that.$emit('onSeek')
            },
            onLoadError(err, url) {
                console.log(`audio loaded error, url=${url}, err=${err}`)
                that.audioStatus = AudioStatus.Error
                that.$emit('onError', {useEngine: true, error: err, type: 'onLoadError'})
            },
            onSeekError(err, url) {
                console.log(`audio seeked error, url=${url}, err=${err}`)
                that.audioStatus = AudioStatus.Error
                that.$emit('onError', {useEngine: true, error: err, type: 'onSeekError'})
            },
            onPlayError(err, url) {
                console.log(`audio played error, url=${url}, err=${err}`)
                that.audioStatus = AudioStatus.Error
                that.$emit('onError', {useEngine: true, error: err, type: 'onPlayError'})
            },
            onVolumeChangeError(err, url) {
                console.log(`audio volumechanged error, url=${url}, err=${err}`)
                that.audioStatus = AudioStatus.Error
                that.$emit('onError', {useEngine: true, error: err, type: 'onVolumeChangeError'})
            },
            onSpeedChangeError(err, url) {
                console.log(`audio speedchanged error, url=${url}, err=${err}`)
                that.audioStatus = AudioStatus.Error
                that.$emit('onError', {useEngine: true, error: err, type: 'onSpeedChangeError'})
            }
        })
        // 引擎的对应的onLoadStart事件
        this.$emit('onLoadStart')
    }
}
export default Audio
</script>
<style lang='less' scoped>
</style>
