/* eslint-disable @typescript-eslint/no-var-requires */
const path = require('path')
const BundleAnalyzerPlugin = require('webpack-bundle-analyzer').BundleAnalyzerPlugin

module.exports = {
    lintOnSave: false,
    parallel: false,
    publicPath: '',
    chainWebpack: config => {
        config.resolve.alias.delete('@')
        config.resolve.symlinks(false)

        // to emit typescript declaration files, see https://github.com/vuejs/vue-cli/issues/1081
        config.module
            .rule('ts')
            .use('ts-loader')
            .loader('ts-loader')
            .tap(opts => {
                opts.transpileOnly = false
                return opts
            })
        config.module.rule('ts').uses.delete('cache-loader')

        config.module
            .rule('source-map')
            .test(/\.js$/)
            .pre()
            .exclude.add(path.join(__dirname, 'node_modules/reflect-metadata'))
            .end()
            .use('source-map-loader')
            .loader('source-map-loader')

        config.output
            .library({
                root: 'StudentExerciseCommonTest',
                amd: 'student-exercise-common-test',
                commonjs: 'student-exercise-common-test'
            })
            .umdNamedDefine(true)

        config.externals({
            vue: {
                root: 'Vue',
                commonjs: 'vue',
                commonjs2: 'vue',
                amd: 'vue'
            },
            'vue-class-component': {
                root: 'VueClassComponent',
                commonjs: 'vue-class-component',
                commonjs2: 'vue-class-component',
                amd: 'vue-class-component'
            },
            'vue-property-decorator': 'vue-property-decorator',
            tslib: 'tslib'
        })

        if (process.env.BUNDLE_ANALYZE) {
            config.plugin('bundle-analyzer').use(BundleAnalyzerPlugin)
        }
    },
    devServer: {
        host: 'local.zhenguanyu.com',
        port: 3000,
        open: true
    }
}
