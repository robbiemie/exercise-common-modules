import { VueConstructor } from 'vue'
import Toast from './main.vue'
import './types'

const install = (Vue: VueConstructor) => {
    const instance = new Toast({
        el: document.createElement('div')
    })

    document.body.appendChild(instance.$el)

    const methods = {
        show: (text: string, duration?: number) => {
            instance.text = text
            if (duration) {
                instance.duration = duration
            }
            instance.isVisible = true
        },
        hide: () => {
            instance.isVisible = false
        }
    }

    Vue.prototype.$toast = methods
}

export default { install, Toast }
