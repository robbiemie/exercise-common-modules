declare module '*.vue' {
    import Vue from 'vue'
    declare class Toast extends Vue {
        text: string
        duration: number
        isVisible: boolean
    }
    export default Toast
}
