/**
 * 模块补充
 */
export interface IToastMethod {
    show: (text: string, duration?: number) => void
    hide: () => void
}

declare module 'vue/types/vue' {
    interface Vue {
        $toast: IToastMethod
    }
}
