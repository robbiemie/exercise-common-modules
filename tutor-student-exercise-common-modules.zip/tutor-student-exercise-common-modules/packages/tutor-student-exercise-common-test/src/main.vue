<template lang="pug">
    .toast-container(v-show="isVisible")
        .toast-box.ignore
            .toast-text {{text}}
</template>

<script lang="ts">
import Vue from 'vue'
import { Component, Emit, Prop, Watch } from 'vue-property-decorator'

@Component
export default class Test extends Vue {
    @Prop({ default: '' }) text!: string
    @Prop({ default: 3000 }) duration!: number
    @Prop({ default: false }) isVisible!: boolean
    private timer?: number

    @Watch('isVisible')
    isVisibleChange(val: boolean) {
        if (val) {
            this.show()
        } else {
            this.hide()
        }
    }

    @Emit('update:isVisible')
    hide() {
        this.clearTimer()
        this.isVisible = false
        return false
    }

    show() {
        this.clearTimer()
        this.$nextTick(() => {
            if (this.duration !== 0) {
                this.timer = window.setTimeout(() => {
                    this.hide()
                }, this.duration)
            }
        })
    }

    private clearTimer() {
        if (this.timer) {
            clearTimeout(this.timer)
            this.timer = undefined
        }
    }
}
</script>

<style lang="less" scoped>
.toast-container {
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
}
.toast-box.ignore {
    position: absolute;
    width: 164px;
    height: 48px;
    left: 50%;
    top: 50%;
    margin-left: -82px;
    margin-top: -24px;
    border-radius: 2px;
    background: rgba(0, 0, 0, 0.8);
    font-size: 15px;
    color: #ffffff;
    display: flex;
    justify-content: center;
    align-items: center;
}
</style>
