'use strict';

import {UAD} from  '../';

const UATests = {
    iphone: [
        'Mozilla/5.0 (iPhone; CPU iPhone OS 14_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 YuanFuDao/7.35.0 (Test)',
        'Mozilla/5.0 (iPhone; CPU iPhone OS 12_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 QQ/8.0.8.458 V1_IPH_SQ_8.0.8_1_APP_A Pixel/1242 Core/WKWebView Device/Apple(iPhone XS) NetType/WIFI QBWebViewType/1 WKType/1'
    ],
    ipad: [
        'Mozilla/5.0 (iPad; CPU OS 14_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 YuanFuDao/7.35.1',
    ],
    ipod: [
        'Mozilla/5.0 (iPod; CPU OS 14_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 YuanFuDao/7.35.1',
    ],
    android: [
        'Mozilla/5.0 (Linux; Android 10; MI 8 Build/QKQ1.190828.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/83.0.4103.101 Mobile Safari/537.36 YuanFuDao/7.37.0',
        'Mozilla/5.0 (Linux; Android 11; PEGM00 Build/RKQ1.200903.002; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/77.0.3865.120 MQQBrowser/6.2 TBS/045713 Mobile Safari/537.36 MMWEBID/3639 MicroMessenger/8.0.9.1940(0x2800093B) Process/tools WeChat/arm64 Weixin NetType/4G Language/zh_CN ABI/arm64'
    ],
    androidPad: [
        'Mozilla/5.0 (Linux; Android 8.0.0; BAH2-W19 Build/HUAWEIBAH2-W19; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/92.0.4515.131 Safari/537.36 isAndroidPad YuanFuDao/7.37.0 AndroidPad',
    ],
    mac: [
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) tutor-electron-student/1.44.0 Chrome/85.0.4183.121 Electron/10.1.5 Safari/537.36 YuanFuDaoMac/1.44.0'
    ],
    windows: [
        'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) tutor-electron-student/6.45.0 Chrome/85.0.4183.121 Electron/10.1.5 Safari/537.36 YuanFuDaoWin/6.45.0',
    ],
    YuanPad: [
        "Mozilla/5.0 (Linux; Android 10; 猿辅导网课平板 Build/POTTER.CB.327012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/80.0.3987.132 Safari/537.36 YuanFuDao/7.37.0 (Test) AndroidPad isAndroidPad isPotter"
    ]
}

test('isAndroid', () => {
    const uad = new UAD(UATests.android[0])
    expect(uad.isAndroid()).toBe(true)
    expect(uad.isAndroidPad()).toBe(false)
});
test('isAndroidPad', () => {
    const uad = new UAD(UATests.androidPad[0])
    expect(uad.isAndroid()).toBe(true)
    expect(uad.isAndroidPad()).toBe(true)
});
test('isIphone', () => {
    const uad = new UAD(UATests.iphone[0])
    expect(uad.isIPhone()).toBe(true)
    expect(uad.isIPad()).toBe(false)
    expect(uad.isIPod()).toBe(false)
});
test('isIPad', () => {
    const uad = new UAD(UATests.ipad[0])
    expect(uad.isIPhone()).toBe(false)
    expect(uad.isIPad()).toBe(true)
    expect(uad.isIPod()).toBe(false)
});
test('isIPod', () => {
    const uad = new UAD(UATests.ipod[0])
    expect(uad.isIPhone()).toBe(false)
    expect(uad.isIPod()).toBe(true)
    expect(uad.isIPad()).toBe(false)
});
test('isIOS', () => {
    const uaiPhone = new UAD(UATests.iphone[0])
    const uaiPod = new UAD(UATests.ipod[0])
    const uaIPad = new UAD(UATests.ipad[0])

    expect(uaiPhone.isIOS()).toBe(true)
    expect(uaiPod.isIOS()).toBe(true)
    expect(uaIPad.isIOS()).toBe(true)
});
test('isMobile', () => {
    const uaIphone = new UAD(UATests.iphone[0])
    const uaAndroid = new UAD(UATests.android[0])
    const uaIpad = new UAD(UATests.ipad[0])
    const uaAndroidPad = new UAD(UATests.androidPad[0])

    expect(uaIphone.isMobile()).toBe(true)
    expect(uaAndroid.isMobile()).toBe(true)
    expect(uaIpad.isMobile()).toBe(false)
    expect(uaAndroidPad.isMobile()).toBe(false)
});

test('isYFDMobile', () => {
    const uaIphone = new UAD(UATests.iphone[0])
    const uaAndroid = new UAD(UATests.android[0])
    const uaIpad = new UAD(UATests.ipad[0])
    const uaAndroidPad = new UAD(UATests.androidPad[0])

    expect(uaIphone.isMobile()).toBe(true)
    expect(uaAndroid.isMobile()).toBe(true)
    expect(uaIpad.isMobile()).toBe(false)
    expect(uaAndroidPad.isMobile()).toBe(false)
});

test('isWindows', () => {
    const uad = new UAD(UATests.windows[0])
    expect(uad.isWindows()).toBe(true)
});

test('isDesktop', () => {
    const uaWindows = new UAD(UATests.windows[0])
    const uaMac = new UAD(UATests.mac[0])

    expect(uaWindows.isDesktop()).toBe(true)
    expect(uaMac.isDesktop()).toBe(true)
});

test('isInnerApp', () => {
    const uad = new UAD(UATests.iphone[0])
    const uad1 = new UAD(UATests.iphone[1])
    expect(uad.isInnerApp()).toBe(true)
    expect(uad1.isInnerApp()).toBe(false)
});

test('isYFDMac', () => {
    const uad = new UAD(UATests.mac[0])
    expect(uad.isYFDMac()).toBe(true)
});

test('isYFDWin', () => {
    const uad = new UAD(UATests.windows[0])
    expect(uad.isWindows()).toBe(true)
});

test('isYFD', () => {
    const uad = new UAD(UATests.iphone[0])
    const uad1 = new UAD(UATests.android[0])
    const uad2 = new UAD(UATests.ipad[0])
    const uad3 = new UAD(UATests.androidPad[0])
    const uad4 = new UAD(UATests.mac[0])
    const uad5 = new UAD(UATests.windows[0])
    const uad6 = new UAD(UATests.ipod[0])
    expect(uad.isYFD()).toBe(true)
    expect(uad1.isYFD()).toBe(true)
    expect(uad2.isYFD()).toBe(true)
    expect(uad3.isYFD()).toBe(true)
    expect(uad4.isYFD()).toBe(true)
    expect(uad5.isYFD()).toBe(true)
    expect(uad6.isYFD()).toBe(true)
});

test('isYuanPad', () => {
    const uad = new UAD(UATests.YuanPad[0])
    expect(uad.isYuanPad()).toBe(true)
})
