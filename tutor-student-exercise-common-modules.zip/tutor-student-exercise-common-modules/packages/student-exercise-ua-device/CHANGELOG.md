# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

### [0.0.9](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/compare/v0.0.1...v0.0.9) (2021-08-31)


### Features

* 部分变量重命名 ([c749528](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/c74952838707527c5d3d9385b4b034dfddb099a4))

### 0.0.8 (2021-08-30)


### Features

* 创建种子项目 ([c0e46e4](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/c0e46e4dcec34f1c8f919903c3ebf95a72335808))
* 初始化项目 ([f947b8f](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/f947b8f8d93f41911adaa4d3741b0b22d2649b6e))
* 接入 rollup 打包 ([342436a](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/342436a478ed734fc11dda05d325f19f4db7a2fe))
* 提取学校选择器公共组件 ([ff58251](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/ff58251db5ffbbc88895d0a75392d7c9bf5460c5))
* 新增 phone brand ([b3f33d1](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/b3f33d1e12411160372c20839066382b12c13586))
* 补充单元测试用例 ([79d2ae1](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/79d2ae13afbdbd8c0956f4ab351ac3cf49bf80f3))
* **examples:** add imageLoad.stories ([8c13d62](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/8c13d623370c0741457ec3b768bc3d837af73a00))
* **image-load:** add imageLoad component ([56bfe5c](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/56bfe5c8d293fdb9572ee610c2adbab08c8cea6b))
* **image-load:** add multiple src input type ([33cd35b](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/33cd35b9b9b3c533164f3a556b2a248063d3d0d9))
* 新增 slide 组件类型定义 ([cd76180](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/cd761802be819a33af6df45d355c2b1967e7492a))


### Bug Fixes

* 修复学校列表未高亮选中项，以及iOS下打开学校选择器后滚动穿透问题 ([e05d8af](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/e05d8af67c606834ccbe2dd044e22303368bff0e))
* 修改轮播自动停止问题 ([f4413b8](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/f4413b8857ae55495b41e47a49ca7ab31e72fd8b))
* 移除无效依赖 ([ce98b70](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/ce98b7067931f7e30417923df01bb1bd7d4cd01e))

### [0.0.7](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/compare/v0.0.6...v0.0.7) (2021-08-16)


### Features

* 接入 rollup 打包 ([342436a](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/342436a478ed734fc11dda05d325f19f4db7a2fe))

### [0.0.6](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/compare/v0.0.5...v0.0.6) (2021-08-16)


### Bug Fixes

* 移除无效依赖 ([ce98b70](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/ce98b7067931f7e30417923df01bb1bd7d4cd01e))

### [0.0.5](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/compare/v0.0.3...v0.0.5) (2021-08-13)


### Features

* 新增 phone brand ([b3f33d1](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/b3f33d1e12411160372c20839066382b12c13586))
* 补充单元测试用例 ([79d2ae1](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/79d2ae13afbdbd8c0956f4ab351ac3cf49bf80f3))

### [0.0.4](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/compare/v0.0.3...v0.0.4) (2021-08-10)

### [0.0.2](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/compare/v0.0.3...v0.0.2) (2021-08-10)

### [0.0.1](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/compare/v0.0.3...v0.0.1) (2021-08-10)
