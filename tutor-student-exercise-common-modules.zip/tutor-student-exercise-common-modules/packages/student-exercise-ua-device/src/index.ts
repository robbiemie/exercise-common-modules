declare global {
    interface Window {
        WebView: any;
        webkit: any;
    }
}

// 获取各个app对应的 productId
export enum PRODUCTID {
    DEFAULT = 0,
    YFDANDROID = 311,
    YFDIPHONE = 301,
    YFDIPAD = 331,
    YFDPC = 328,
    YFDMAC = 391,

    YTKANDROID = 111,
    YTKIPHONE = 101,
    YTKIPAD = 121,

    YSTANDROID = 211,
    YSTIPHONE = 201,
    YSTIPAD = 221,

}

export function getQuery(url?: string | null) {
    url = url || window.location.search
    const obj: { [key: string]: string } = {}
    const reg = new RegExp('[?&](' + ('[^&=#]+') + ')=([^&#]+)?', 'g')

    try {
        url.replace(reg, ($0, $1, $2) => {
            return obj[$1] = $2 ? decodeURIComponent($2) : ''
        })
    } catch (e) { }

    return obj
}

const query = getQuery()
const productId = Number(query.PRODUCTID)

export class UAD {
    public constructor(public userAgent: string) {
    }

    getUserAgent() {
        return this.userAgent
    }

    // 判定设备类型，型号
    isAndroid() {
        return /Android/i.test(this.userAgent)
    }
    isAndroidPad() {
        return /Android\s?Pad/i.test(this.userAgent)|| this.isAndroid() && !(/mobile/i.test(this.userAgent)) ||  /isAndroidPad/.test(this.userAgent)
    }
    // 只针对移动端
    isIOS() {
        return this.isIPhone() || this.isIPad() || this.isIPod()
    }
    isIPod() {
        return /iPod/i.test(this.userAgent)
    }
    isIPhone() {
        return /iPhone/i.test(this.userAgent) || productId === PRODUCTID.YFDIPHONE
    }
    isIPad() {
        return /iPad/i.test(this.userAgent) || (/Macintosh/i.test(this.userAgent) && 'ontouchend' in document) || productId === PRODUCTID.YFDIPAD // pados
    }
    isPad() {
        return this.isAndroidPad() || this.isIPad()
    }
    isMobile() {
        return (this.isIOS() || this.isAndroid()) && !this.isPad()
    }
    isYFDMobile() {
        return this.isInnerApp() && this.isMobile()
    }
    isTablet() {
        return this.isAndroid() && !(/mobile/i.test(this.userAgent))
    }
    isWindows () {
        return /Windows/i.test(this.userAgent)
    }
    isDesktop () {
        return this.isYFDMac() || this.isYFDWin() || this.isYFDPc()
    }
    // 是否是YFD的app
    isInnerApp() {
        return /YuanTiKu|YuanSouTi|YuanFuDao/i.test(this.userAgent)
    }
    isYFDMac() {
        return /YuanFuDaoMac/i.test(this.userAgent)
    }
    isYFDWin() {
        return /YuanFuDaoWin/i.test(this.userAgent)
    }
    isYFDPc() {
        return /YuanFuDaoPC/i.test(this.userAgent)
    }
    isYFD() {
        return /YuanFuDao/i.test(this.userAgent)
    }
    isYTK() {
        return /YuanTiKu/i.test(this.userAgent)
    }
    isYST() {
        return /YuanSouTi/i.test(this.userAgent)
    }
    isWechat() {
        return /MicroMessenger\//.test(this.userAgent)
    }
    // 是否是猿辅导自研pad
    isYuanPad() {
        return /isPotter/.test(this.userAgent)
    }

    getBrand() {
        const isHuawei = /huawei/i.test(this.userAgent)
        const isHonor = /honor/i.test(this.userAgent)
        const isOppo = /oppo/i.test(this.userAgent)
        const isOppoR15 = /pacm00/i.test(this.userAgent)
        const isVivo = /vivo/i.test(this.userAgent)
        const isXiaomi = /mi\s/i.test(this.userAgent)
        const isXiaomi2s = /mix\s/i.test(this.userAgent)
        const isRedmi = /redmi/i.test(this.userAgent)
        const isRedmiNote = /M2010J19SC/i.test(this.userAgent)

        if (this.isIPhone) {
            return 'iphone'
        } else if (isHuawei) {
            return 'huawei'
        } else if (isHonor) {
            return 'honor'
        } else if (isOppo || isOppoR15) {
            return 'oppo'
        } else if (isVivo) {
            return 'vivo'
        } else if (isXiaomi || isRedmi || isXiaomi2s || isRedmiNote) {
            return 'xiaomi'
        } else {
            return 'other'
        }
    }

    getProductId() {
        if (this.isYFD()) {
            if (this.isAndroid()) {
                return PRODUCTID.YFDANDROID
            } else if (this.isIPhone()) {
                return PRODUCTID.YFDIPHONE
            } else if (this.isIPad()) {
                return PRODUCTID.YFDIPAD
            } else if (this.isYFDPc() || this.isYFDWin()) {
                return PRODUCTID.YFDPC
            } else if (this.isYFDMac()) {
                return PRODUCTID.YFDMAC
            }
            return PRODUCTID.DEFAULT
        }
        else if (this.isYTK()) {
            if (this.isAndroid()) {
                return PRODUCTID.YTKANDROID
            } else if (this.isIPhone()) {
                return PRODUCTID.YTKIPHONE
            } else if (this.isIPad()) {
                return PRODUCTID.YTKIPAD
            }
            return PRODUCTID.DEFAULT
        }
        else if (this.isYST()) {
            if (this.isAndroid()) {
                return PRODUCTID.YSTANDROID
            } else if (this.isIPhone()) {
                return PRODUCTID.YSTIPHONE
            } else if (this.isIPad()) {
                return PRODUCTID.YSTIPAD
            }
            return PRODUCTID.DEFAULT
        }
        return PRODUCTID.DEFAULT
    }

    getClientVersion() {
        const mathces = this.userAgent.match(/((?:YuanFuDao|YuanTiKu|YuanSouTi)[^/]*)\/([0-9.]+)/)

        return mathces && mathces[2] || ''
    }
    getBrowserVersion() {
        const userAgent = this.userAgent
        // ie
        let result = userAgent.match(/msie ([\d.]+)/i)
        if (result && result[1]) {
            return result[1]
        }
        // firefox
        result = userAgent.match(/firefox\/([\d.]+)/i)
        if (result && result[1]) {
            return result[1]
        }
        // chrome
        result = userAgent.match(/chrome\/([\d.]+)/i)
        if (result && result[1]) {
            return result[1]
        }
        // opera
        result = userAgent.match(/opera.([\d.]+)/i)
        if (result && result[1]) {
            return result[1]
        }
        // safari

        result = userAgent.match(/version\/([\d.]+).*safari/i)
        if (result && result[1]) {
            return result[1]
        }

        return userAgent
    }

}


/**
* compare version
* @param v1 source version
* @param v2 target version
* 1 : v1 > v2
* 0 : v1 = v2
* -1: v1 < v2
*/
export function compareVersion(v1: string, v2: string) {
    const v1Arr = v1.split('.')
    const v2Arr = v2.split('.')
    const v1Len = v1Arr.length
    let i = 0

    for (; i < v1Len; ++i) {
        const num1 = Number.parseInt(v1Arr[i] || '0', 10)
        const num2 = Number.parseInt(v2Arr[i] || '0', 10)

        if (num1 !== num2) {
            return num1 > num2 ? 1 : -1
        }
    }
    return 0
}

export default new UAD(window.navigator.userAgent)
