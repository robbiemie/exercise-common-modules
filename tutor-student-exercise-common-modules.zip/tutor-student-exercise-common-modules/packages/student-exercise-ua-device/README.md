# `@tutor/student-exercise-ua-device`

web练习系统设备UA工具库

## Usage

```
import UAD from '@tutor/student-exercise-ua-device'

<!-- Examples -->
export const isIPod = UAD.isIPod()
export const isWechat = UAD.isWechat()
export const isIPad = UAD.isIPad()
export const isIPhone = UAD.isIPhone()
export const isAndroid = UAD.isAndroid()
...
```
