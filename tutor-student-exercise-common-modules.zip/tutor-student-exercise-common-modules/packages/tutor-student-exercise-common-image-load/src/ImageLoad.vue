<template>
    <div class="image-load-container">
        <img
            v-bind="$attrs"
            v-on="$listeners"
            v-if="status === ImgLoadStatus.SUCCESS"
            :src="imgSrc"
            :style="imageStyle"
            :class="{ 'inner-image': true, 'inner-image-center': alignCenter }"
            @click="handleImgClick"
        />
        <slot v-if="status === ImgLoadStatus.INIT" name="placeholder">
            <!-- 占位图 -->
        </slot>
        <slot v-if="status === ImgLoadStatus.LOADING" name="loading">
            <!-- 加载中，默认样式 -->
            <div class="image-loading"></div>
        </slot>
        <slot v-if="status === ImgLoadStatus.FAILED" name="error">
            <!-- 加载失败，默认样式 -->
            <div class="image-retry" @click="handleImgReload"></div>
        </slot>
    </div>
</template>

<script lang="ts">
import Vue from 'vue'
import { Component, Emit, Prop, Watch } from 'vue-property-decorator'
enum ImgLoadStatus {
    INIT = 0,
    LOADING,
    SUCCESS,
    FAILED
}
enum ImgLoadEvent {
    BEFORE_RELOAD = 'beforeReload',
    LOAD_SUCCESS = 'loadSuccess',
    LOAD_FAILED = 'loadFailed',
    IMAGE_CLICK = 'imageClick'
}
// https://developer.mozilla.org/en-US/docs/Web/CSS/object-fit
enum FitEnum {
    NONE = 'none',
    CONTAIN = 'contain',
    COVER = 'cover',
    FILL = 'fill',
    SCALE_DOWN = 'scale-down'
}
const isSupportObjectFit = () => document.documentElement.style.objectFit !== undefined
// TODO: 支持 CDN 切换
// TODO: 支持 lazy load
// TODO: 支持 previewer
@Component
export default class ImageLoad extends Vue {
    @Prop({ default: '' }) src!: string | Promise<string> | Function
    @Prop({ default: FitEnum.NONE }) fit?: FitEnum
    // 在已加载成功的场景下，再次触发加载时，是否展示 loading；
    // 即在一次完整的流程中是否只展示一次 loading；
    @Prop({ default: false }) isShowLoadingOnce!: boolean
    @Prop({ default: undefined }) timeoutInSecond?: number // 单位 ms

    ImgLoadStatus = ImgLoadStatus
    loadTimer?: number
    status: ImgLoadStatus = ImgLoadStatus.INIT
    imageWidth?: number
    imageHeight?: number
    isTimeout = false // 是否已超时
    imgSrc?: string

    mounted() {
        this.loadImage()
    }
    beforeDestroy() {
        this.clearLoadTimer()
    }
    @Watch('src')
    imgSrcChange() {
        this.loadImage()
    }
    loadImage() {
        if (!this.src) {
            return
        }
        if (!(this.status === ImgLoadStatus.SUCCESS && this.isShowLoadingOnce)) {
            this.status = ImgLoadStatus.LOADING
        }
        this.initLoadTimer()
        if (typeof this.src === 'string') {
            this.initImage(this.src)
        }
        if (this.src instanceof Function) {
            const src = this.src()
            this.initImage(src)
        }
        if (this.src instanceof Promise) {
            this.src.then(src => {
                this.initImage(src)
            })
        }
    }
    initImage(src: string) {
        const img = new Image()
        img.onload = e => this.handleImgLoadSuccess(e, img)
        img.onerror = e => this.handleImgLoadFailed(e)
        Object.keys(this.$attrs).forEach(key => {
            const value = this.$attrs[key]
            img.setAttribute(key, value)
        })
        img.src = src
        this.imgSrc = src
    }
    get imageStyle() {
        const { fit } = this
        if (this.status === ImgLoadStatus.SUCCESS && fit) {
            return isSupportObjectFit() ? { 'object-fit': fit } : this.getImageStyle(fit)
        }
        return {}
    }
    get alignCenter() {
        const { fit } = this
        return !isSupportObjectFit() && fit !== FitEnum.FILL
    }
    getImageStyle(fit: FitEnum) {
        const { imageWidth, imageHeight } = this
        const { clientWidth: containerWidth, clientHeight: containerHeight } = this.$el
        if (!imageWidth || !imageHeight || !containerWidth || !containerHeight) {
            return {}
        }
        const imageAspectRatio = imageWidth / imageHeight
        const containerAspectRatio = containerWidth / containerHeight
        if (fit === FitEnum.SCALE_DOWN) {
            const isSmaller = imageWidth < containerWidth && imageHeight < containerHeight
            fit = isSmaller ? FitEnum.NONE : FitEnum.CONTAIN
        }
        switch (fit) {
            case FitEnum.NONE:
                return { width: 'auto', height: 'auto' }
            case FitEnum.CONTAIN:
                return imageAspectRatio < containerAspectRatio ? { width: 'auto' } : { height: 'auto' }
            case FitEnum.COVER:
                return imageAspectRatio < containerAspectRatio ? { height: 'auto' } : { width: 'auto' }
            default:
                return {}
        }
    }
    handleImgLoadFailed(e: Event | string) {
        this.status = ImgLoadStatus.FAILED
        this.$emit(ImgLoadEvent.LOAD_FAILED, e)
    }
    handleImgLoadSuccess(e: Event, img: HTMLImageElement) {
        if (this.isTimeout) {
            return
        }
        this.status = ImgLoadStatus.SUCCESS
        this.imageWidth = img.width
        this.imageHeight = img.height
        this.clearLoadTimer()
        this.$emit(ImgLoadEvent.LOAD_SUCCESS, e, img)
    }
    handleImgClick() {
        this.$emit(ImgLoadEvent.IMAGE_CLICK)
    }
    handleImgReload() {
        this.$emit(ImgLoadEvent.BEFORE_RELOAD)
        this.loadImage()
    }
    initLoadTimer() {
        if (!this.timeoutInSecond) {
            return
        }
        this.clearLoadTimer()
        this.loadTimer = window.setTimeout(() => {
            this.status = ImgLoadStatus.FAILED
            this.$emit(ImgLoadEvent.LOAD_FAILED, new Error('timeout'))
            this.isTimeout = true
        }, this.timeoutInSecond * 1000)
    }
    clearLoadTimer() {
        if (this.loadTimer) {
            clearTimeout(this.loadTimer)
        }
        this.isTimeout = false
    }
}
</script>

<style lang="less" scoped>
.image-load-container {
    display: inline-block;
    position: relative;
    overflow: hidden;
}
.image-loading,
.image-retry {
    position: absolute;
    display: inline-block;
    width: 30%;
    height: 30%;
    left: 50%;
    top: 50%;
    transform: translate(-50%, -50%);
    background-position: center;
    background-repeat: no-repeat;
    background-size: contain;
}
.image-loading {
    background-image: url('./assets/loading.svg');
}
.image-retry {
    cursor: pointer;
    background-image: url('./assets/retry.svg');
}
.inner-image {
    // https://stackoverflow.com/questions/49923624/object-fit-fill-does-not-working
    height: 100%;
    width: 100%;
}
.inner-image-center {
    display: inline-block;
    position: relative;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
}
</style>
