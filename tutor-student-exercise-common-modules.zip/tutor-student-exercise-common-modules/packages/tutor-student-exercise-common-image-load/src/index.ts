import ImageLoad from './ImageLoad.vue'
import { VueConstructor } from 'vue'
ImageLoad.install = (Vue: VueConstructor) => {
    Vue.component('ImageLoad', ImageLoad)
}
export default ImageLoad
