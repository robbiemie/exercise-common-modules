# `tutor-student-exercise-common-image-load`

> image load component

## Usage

#### 属性定义

| props             |                      类型                      | 作用                   |
| ----------------- | :--------------------------------------------: | ---------------------- |
| src               |     string \| Promise<string> \| Function      | 当前选中学校           |
| fit               | fill \| contain \| cover \| none \| scale-down | 图片相对父容器适应设置 |
| timeoutInSecond   |                     number                     | 设置超时时长           |
| isShowLoadingOnce |                    boolean                     | 只展示一次 loading     |

### slot 定义

| slot        |           作用            |
| ----------- | :-----------------------: |
| placeholder | 当 src 未设置时的占位内容 |
| loading     |     加载时的展示内容      |
| error       |   加载异常时的展示内容    |

### event 定义

| event        |            参数            | 作用                  |
| ------------ | :------------------------: | --------------------- |
| beforeReload |            void            | 重新加载前触发        |
| loadSuccess  | (Event, HTMLImageElement)  | 加载成功触发          |
| loadFailed   | (Event \| string \| Error) | 加载失败/加载超时触发 |
| imageClick   |            void            | 点击图片后触发        |

### 导入 imageLoad 组件

```
// 下载包
npm install @tutor/student-exercise-common-image-load
```

```
// 导入组件 & css 样式
import '@tutor/student-exercise-common-image-load/dist/student-exercise-common-image-load.css'

import ImageLoad from '@tutor/student-exercise-common-image-load'
```

## 使用示例

```
<template>
    <ImageLoad :src="urlPromise" :fit="'fill'" ref="imageLoad" :timeoutInSecond="10">
        <template v-slot:error>
            <div @click="$refs.imageLoad.handleImgReload"> RETRY </div>
        </template>
        <template v-slot:loading>
            <div> LOADING</div>
        </template>
    </ImageLoad>
</template>

<script lang="ts">
import Vue from "vue";
import { Component } from "vue-property-decorator";
import ImageLoad from '@tutor/student-exercise-common-image-load'
import '@tutor/student-exercise-common-image-load/dist/student-exercise-common-image-load.css'
@Component({ImageLoad})
export default class App extends Vue {
    urlPromise = new Promise(resolve => {
    setTimeout(() => {
        resolve('https://yfd1.fbcontent.cn/s/logo-edb6dab9c4.png')
    }, 3000)
})
}
</script>
```

## StoryBook

[storeybook story link](https://static-nginx-test.oss-cn-beijing.aliyuncs.com/phoenix-sites/tutor-student-exercise-common-modules/TESTING/master/public/index.html?path=/story/imageload)
