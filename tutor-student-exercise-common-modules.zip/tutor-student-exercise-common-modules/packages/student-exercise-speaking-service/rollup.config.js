const path = require('path');
const babel = require('rollup-plugin-babel');
const pkg = require('./package.json');
const typescript = require('rollup-plugin-typescript2');

const extensions = ['.js', '.ts'];

const resolve = function(...args) {
  return path.resolve(__dirname, ...args);
};

module.exports = {
  input: resolve('./src/index.ts'),
  output: [{
      file: pkg.main,
      format: 'umd',
      name: "ua-device"
  }, {
      file: pkg.module,
      format: 'esm',
  }],
  plugins: [
    typescript({
        tsconfig: './tsconfig.json'
    }),
    {
      extensions,
      modulesOnly: true,
    },
    babel({
      exclude: 'node_modules/**',
      extensions,
    }),
  ],
};
