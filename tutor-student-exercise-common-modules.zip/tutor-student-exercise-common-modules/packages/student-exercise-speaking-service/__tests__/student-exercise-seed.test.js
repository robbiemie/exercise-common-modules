'use strict';

const studentExerciseSpeakingService = require('..');

describe('@tutor/student-exercise-speaking-service', () => {
    it('needs tests');
});
