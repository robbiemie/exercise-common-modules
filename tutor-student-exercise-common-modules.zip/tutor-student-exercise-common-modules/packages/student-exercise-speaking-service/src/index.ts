import SpeakingService from './SpeakingService'
export * from '@tutor/exercise-speaking-proto'
export * from './constants'
export * from './SpeakingService'

export default SpeakingService
