import {
    BridgeUtil,
    BridgeProto,
    container,
    AuthorityManager,
    BaseSpeakingManager,
} from '@tutor/box-bridge-ts'
import { Subscription } from 'rxjs'
import { RecodingStatus, ErrorCode, SpeakingHooksType } from './constants'
import {
    NO_RESULT_TITLE,
    NO_RESULT_CONTENT,
    NO_RESULT_CONFRIM,
    NO_RESULT_CANCEL,
    NETWORK_ERROR_TITLE,
    NETWORK_ERROR_CONTENT,
    NETWORK_ERROR_CONTRIM,
    MIC_AUTHORITY_TITLE,
    NO_MIC_AUTHORITY_CONTENT,
    NO_MIC_AUTHORITY_CONFIRM,
    MIC_AUTHORITY_ERROR_CONTENT,
    MIC_AUTHORITY_ERROR_CONFIRM,
    SOCKET_NETWORK_ERROR_TITLE,
    SOCKET_NETWORK_ERROR_CONTENT,
    SPEAKING_LIMIT_ERROR_CONTENT,
    SOCKET_NETWORK_ERROR_CONFRIM,
    SOCKET_NETWORK_ERROR_CANCEL,
 } from './constants/Messages'
import { Speaking } from '@tutor/exercise-speaking-proto'
import SpeakingBase, { DialogOption, Pronunciation } from './SpeakingBase'
export interface RecordOption {
    webAppId: string // 当前业务id
    recordText: string // 录音文本
    wordPronunciation: Pronunciation[]
    multiTexts?: Speaking.ITextWithKeyWordsProto[]
    wsServeAddress?: string // websocket 地址
    webAppVersion?: string // version
    productId?: string //
    platform?: string // web、ios、android
    model?: string //
    userId?: string // 自定义发音
    audioUrl?: string // 解析使用
    businessParam?: object
}
export interface MessageOption {
    noResultTitle?: string
    noResultContent?: string
    noResultConfirm?: string
    noResultCancel?: string
    networkErrorTitle?: string
    networkErrorContent?: string
    networkErrorConfirm?: string
    micAuthorityTitle?: string
    noMicAuthorityContent?: string
    noMicAuthorityConfirm?: string
    micAuthorityErrorContent?: string
    micAuthorityErrorConfirm?: string
    socketNetworkErrorTitle?: string
    socketNetworkErrorContent?: string
    speakingLimitErrorContent?: string
    socketNetworkErrorConfirm?: string
    socketNetworkErrorCancel?: string
}
export interface SpeakingServiceProps {
    messages?: MessageOption | null
    recordOption: RecordOption | null
    onDialogCallback?: (options: DialogOption) => void
    onToastCallback?: (message: string) => void
}
export interface RecordResult {
    isMulti: boolean,
    audioId?: string | null;
    audioDuration: string;
    audioUrl?: string | null;
    score?: number | null;
    scoreReport?: Speaking.IScoreReportProto | null;
    multiTextsScoreReport?: Speaking.IMultiTextsScoreReportProto|null,
}
type AsyncFunction = () => Promise<boolean>

type UpdateSpeakingStatusCallback = (
    status: RecodingStatus
) => void
type UpdateVolumeChangeCallback = (volume: number) => void
type UpdateRecordResultCallback = (result: RecordResult) => void
const MAX_LIMIT_TIME_IN_MS = 40 * 1000// 超时时长
const WAIT_SCORING_TIME_IN_MS = 10 * 1000 // 等待打分时长
export const checkMicAuthority = SpeakingBase.checkMicAuthority
export const ringBell = SpeakingBase.ringBell
export const setBGMVolume = SpeakingBase.setBGMVolume
export default class SpeakingService {
    private hooks = new Map<SpeakingHooksType, AsyncFunction>()
    private recordStatus: RecodingStatus = RecodingStatus.Idle
    private recordResult: RecordResult | null = null
    private volume: number = 0.5 // 音量
    private recordText: string
    private multiTexts: Speaking.ITextWithKeyWordsProto[]
    private maxLimitTimer: number = 0 // 最大限制时长
    private waitScoringTimer: number = 0 // 等待得分结果
    private waitScoringLocked: boolean = false // 加锁判断，等待得分结果已经超时
    private recordEndTimer: number = 0 // 正常结束 s
    private recordOption: RecordOption | null = null
    private recordFailed: Subscription
    private socketFailed: Subscription
    private volumeSub: Subscription
    private downSub: Subscription
    private webAppId: string
    private webAppVersion: string
    private productId: string
    private platform: string
    private model: string
    private userId: string
    private businessParam: object
    private messages: MessageOption | null
    private wordPronunciation: Pronunciation[]
    private speakingBase: SpeakingBase
    private updateStatusCallback: UpdateSpeakingStatusCallback
    private updateVolumeChangeCallback: UpdateVolumeChangeCallback // 音量变更
    private updateRecordResultCallback: UpdateRecordResultCallback // 打分结果
    private updatePlayEffectCallback: () => void // 展示打分动效
    private onDialogCallback: (options: DialogOption) => void | null
    private onToastCallback: (message: string) => void | null

    constructor(props: SpeakingServiceProps) {
        const { recordOption, onDialogCallback, onToastCallback, messages } = props
        this.speakingBase = new SpeakingBase()
        this.recordOption = recordOption
        this.recordText = recordOption.recordText || ''
        this.multiTexts = recordOption.multiTexts || []
        this.onDialogCallback = onDialogCallback || null
        this.onToastCallback = onToastCallback || null
        this.webAppId = recordOption.webAppId || ''
        this.webAppVersion = recordOption.webAppVersion || ''
        this.productId = recordOption.productId || ''
        this.platform = recordOption.platform || ''
        this.model = recordOption.model || ''
        this.userId = recordOption.userId || ''
        this.businessParam = recordOption.businessParam || {}
        this.messages = messages
        this.wordPronunciation = recordOption.wordPronunciation
    }
    // todo: 支持传入一个数组类型
    public registerHook(hookName: SpeakingHooksType, callback: AsyncFunction) {
        this.hooks.set(hookName, callback)
    }
    /**
     * 监听跟读组件状态变化
     * @param callback UpdateSpeakingStatusCallback
     */
    public onSpeakingStatusChange(callback: UpdateSpeakingStatusCallback) {
        if (callback) {
            this.updateStatusCallback = callback
        }
    }
    private updateSpeakingStatus(status: RecodingStatus) {
        this.recordStatus = status
        if (this.updateStatusCallback) {
            this.updateStatusCallback(status)
        }
    }
    public subscribeSpeakingMessage(handleStartRecorderError?, handleOpenWebSocketError?) {
        const baseSpeakingManager = container.resolve(BaseSpeakingManager)
        // 处理中途异常
        this.recordFailed = baseSpeakingManager.onStartRecordingFailed(
            (errCode?: BridgeProto.ASpeakingState.ErrorType) => {
                if(handleStartRecorderError) {
                    // 主动处理异常
                    handleStartRecorderError(errCode)
                } else {
                    this.handleStartRecorderError()
                }
            }
        )
        this.socketFailed = baseSpeakingManager.onWebSocketConnectFailed(
            (
                errCode?: BridgeProto.ASpeakingState.ErrorType,
                clientErrorCode?: number
            ) => {
                if(handleOpenWebSocketError) {
                    handleOpenWebSocketError(errCode, clientErrorCode)
                } else {
                    this.handleOpenWebSocketError(errCode, clientErrorCode)
                }
            }
        )
        // 音量变化
        this.volumeSub = baseSpeakingManager.onVolumeLevel(
            (volumeLevel: number) => {
                this.volume = (volumeLevel + 1) / 10
                if(this.updateVolumeChangeCallback) {
                    this.updateVolumeChangeCallback(
                        this.volume
                    )
                }
            }
        )
        // 处理下发消息
        this.downSub = this.speakingBase.onDownStreamMessage(
            async (msg: Speaking.IDownstreamMessage) => {
                switch (msg.type) {
                    // 录音完成，等待评分
                    case Speaking.DownstreamMessage.DownstreamMessageType.VAD:
                        this.updateSpeakingStatus(RecodingStatus.Loading)
                        this.waitScoringTimer = window.setTimeout(async () => {
                            this.waitScoringLocked = true
                            // 10s 未返回打分结果弹窗提示
                            this.onDialogCallback &&
                                this.onDialogCallback({
                                    title: BridgeUtil.isWin() ? this.messages?.noResultTitle || NO_RESULT_TITLE : '',
                                    content: this.messages?.noResultContent || NO_RESULT_CONTENT ,
                                    confirmButtonText: this.messages?.noResultConfirm || NO_RESULT_CONFRIM,
                                    cancelButtonText: this.messages?.noResultCancel || NO_RESULT_CANCEL,
                                    onConfirm: async () => {
                                        await this.startSpeaking()
                                    },
                                    onCancel() {
                                    },
                                })
                            await this.stopSpeaking()
                            await this.clean()
                        }, WAIT_SCORING_TIME_IN_MS)
                        break
                    //  分数出来
                    case Speaking.DownstreamMessage.DownstreamMessageType.MULTI_TEXT_SCORE:
                    case Speaking.DownstreamMessage.DownstreamMessageType.SCORE:
                        // 清理10s 定时器
                        if (this.waitScoringTimer) {
                            clearTimeout(this.waitScoringTimer)
                            this.waitScoringTimer = null
                        }
                        if (this.waitScoringLocked) {
                            this.waitScoringLocked = false
                            return
                        }
                        const isMulti = msg.type === Speaking.DownstreamMessage.DownstreamMessageType.MULTI_TEXT_SCORE
                        // msg 分数处理
                        this.recordResult = {
                            isMulti,
                            audioId: msg.audioId,
                            audioDuration: msg.audioDuration!.toString(),
                            audioUrl: msg.audioUrl,
                            score: msg.score,
                            scoreReport: msg.scoreReport,
                            multiTextsScoreReport: msg.multiTextsScoreReport,
                        }
                        // 获取得分结果
                        if(this.updateRecordResultCallback) {
                                this.updateRecordResultCallback(
                                this.recordResult
                            )
                        }
                        await this.stopSpeaking()
                            .then(() => {
                                // 展示打分结果
                                if(this.updatePlayEffectCallback) {
                                    this.updatePlayEffectCallback()
                                }
                            })
                            .catch(err => {
                                console.error('stopSpeaking error', err)
                            })
                        await this.clean()
                        break
                    default:
                        break
                }
            }
        )
    }
    public subscribeVolumeChange(callback:UpdateVolumeChangeCallback) {
        if(callback) {
            this.updateVolumeChangeCallback = callback
        }
    }
    public subscribeRecordResult(callback:UpdateRecordResultCallback) {
        if(callback) {
            this.updateRecordResultCallback = callback
        }
    }
    public subscribePlayEffect(callback: () => void) {
        if(callback) {
            this.updatePlayEffectCallback = callback
        }
    }

    public unSubscribeSpeakingMessage() {
        if (this.downSub) {
            this.downSub.unsubscribe()
        }
        if (this.volumeSub) {
            this.volumeSub.unsubscribe()
        }
        if (this.socketFailed) {
            this.socketFailed.unsubscribe()
        }
        if (this.recordFailed) {
            this.recordFailed.unsubscribe()
        }
    }
    public async callhook(hookName: SpeakingHooksType) {
        const hookCallback = this.hooks.get(hookName)
        if(hookCallback) {
            // 调用异步 hookCallback
            await hookCallback()
        }
    }
    /**
     * 开始跟读
     * @param recordEndTimeInMs 跟读结束倒计时时间
     */
    public async startSpeaking(recordEndTimeInMs: number = 40000 ) {
        this.updateSpeakingStatus(RecodingStatus.RecordStart)
        // 处理初始数据
        const text = this.recordText
        const multiTexts = this.multiTexts || null
        try {
            await this.callhook(SpeakingHooksType.BeforeCheckMicAuthority)
            // 检查mic 权限
            await checkMicAuthority()
        } catch (err) {
            this.updateSpeakingStatus(RecodingStatus.RecordCheckFail)
            this.uploadLogCheckMic(err)
            // 返回 reject，阻断后续逻辑
            return Promise.reject(ErrorCode.Micphone)
        }
        this.updateSpeakingStatus(RecodingStatus.RecordCheckSuccess)
        // 开启客户端录音
        await this.callhook(SpeakingHooksType.BeforeStartRecorder)
        // 初始化录音成功
        await this.speakingBase.startRecorder().catch(err=> {
            this.updateSpeakingStatus(RecodingStatus.StartRecorderFail)
            return Promise.reject(ErrorCode.StartRecorder)
        })
        await this.callhook(SpeakingHooksType.BeforeOpenWebsocket)
        // 打开socket
        await this.speakingBase.openWebsocket(this.recordOption.wsServeAddress).catch(
            (err: Error) => {
                this.updateSpeakingStatus(RecodingStatus.ConnectionFail)
                this.stopSpeaking()
                return Promise.reject(ErrorCode.Websocket)
            }
        )
        await this.callhook(SpeakingHooksType.BeforeStartSpeaking)
        await this.speakingBase.startSpeaking(text, multiTexts,this.wordPronunciation, {
            webAppId: this.webAppId,
            webAppVersion: this.webAppVersion,
            productId: this.productId,
            platform: this.platform,
            model: this.model,
            userId: this.userId,
            businessParam: this.businessParam,
        }).catch(
            (err: Error) => {
                this.updateSpeakingStatus(RecodingStatus.RecordStartFail)
                this.stopSpeaking()
                return Promise.reject(ErrorCode.StartSpeaking)
            }
        )
        this.updateSpeakingStatus(RecodingStatus.RecordRunning)
        // 兜底逻辑
        // 如果录制时长，大于最大限制时长，则最大限制时长 +1s
        let maxLimitTimeInMs = recordEndTimeInMs > MAX_LIMIT_TIME_IN_MS ? MAX_LIMIT_TIME_IN_MS + 1000 : MAX_LIMIT_TIME_IN_MS
        // 限制40s
        this.maxLimitTimer = window.setTimeout(async () => {
            const message = this.messages?.networkErrorContent || NETWORK_ERROR_CONTENT
            // 先结束跟读
            await this.stopSpeaking()
            // 弹窗提示
            this.onDialogCallback &&
                this.onDialogCallback({
                    title: BridgeUtil.isWin() ? this.messages?.networkErrorTitle || NETWORK_ERROR_TITLE : '',
                    content: message,
                    confirmButtonText: this.messages?.networkErrorConfirm || NETWORK_ERROR_CONTRIM,
                })
        }, maxLimitTimeInMs)
        // 跟读倒计时结束，自动停止跟读
        this.recordEndTimer = window.setTimeout(async () => {
            await this.stopSpeaking()
            // 注意：不要加下面这句！！！否则收不到客户端 message
            // this.clean()
        }, recordEndTimeInMs)
    }
    public async stopSpeaking() {
        // clear limit 40s
        if (this.maxLimitTimer) {
            clearTimeout(this.maxLimitTimer)
            this.maxLimitTimer = null
        }
        // clear normal 时间
        if (this.recordEndTimer) {
            clearTimeout(this.recordEndTimer)
            this.recordEndTimer = null
        }
        // stop 和 score 触发多次
        if (
            [RecodingStatus.Idle, RecodingStatus.Loading].includes(
                this.recordStatus
            )
        ) {
            return
        }
        await this.callhook(SpeakingHooksType.BeforeStopRecorder)
        // 获取设备信息
        const params = await this.speakingBase.stopRecorder().catch(err => {
            return Promise.reject(ErrorCode.StopRecorder)
        })
        await this.callhook(SpeakingHooksType.BeforeStopSpeaking)
        await this.speakingBase.stopSpeaking(params).catch(err => {
            return Promise.reject(ErrorCode.StopSpeaking)
        })
        await this.callhook(SpeakingHooksType.AfterStopSpeaking)
        this.updateSpeakingStatus(RecodingStatus.RecordEnd)
    }
    // 清理状态
    public async clean() {
        this.updateSpeakingStatus(RecodingStatus.Idle)
        // clear limit 40s
        if (this.maxLimitTimer) {
            clearTimeout(this.maxLimitTimer)
            this.maxLimitTimer = null
        }
        // clear normal 时间
        if (this.recordEndTimer) {
            clearTimeout(this.recordEndTimer)
            this.recordEndTimer = null
        }
        // 兼容站外 H5
        this.speakingBase.closeWebsocket()
            .then(() => {})
    }
    public revertToReady() {
        if (this.recordStatus === RecodingStatus.Idle) {
            return
        }
        this.updateSpeakingStatus(RecodingStatus.Loading)
        setTimeout(() => {
            this.updateSpeakingStatus(RecodingStatus.Idle)
        }, 1000)
    }
    async handleStartRecorderError(
    ) {
        if (this.speakingBase.noAuthLock === true) return
        this.speakingBase.noAuthLock = true
        let content = ''
        let buttonText = ''
        let needJumpSettingPage = false
        if (BridgeUtil.isWin) {
            content = this.messages?.noMicAuthorityContent || NO_MIC_AUTHORITY_CONTENT
            buttonText = this.messages?.noMicAuthorityConfirm || NO_MIC_AUTHORITY_CONFIRM
            needJumpSettingPage = true
        } else {
            content = this.messages?.micAuthorityErrorContent || MIC_AUTHORITY_ERROR_CONTENT
            buttonText = this.messages?.micAuthorityErrorConfirm ||MIC_AUTHORITY_ERROR_CONFIRM
        }
        const authorityManager = container.resolve(AuthorityManager)
        // dialog
        this.onDialogCallback &&
            this.onDialogCallback({
                title: BridgeUtil.isWin() ? this.messages?.micAuthorityTitle || MIC_AUTHORITY_TITLE : '',
                content,
                confirmButtonText: buttonText,
                onConfirm() {
                    if (needJumpSettingPage) {
                        authorityManager.jumpSettingPage()
                    }
                },
                onCancel() {
                },
            })
        // 回退以前状态
        if ([RecodingStatus.Loading].includes(this.recordStatus)) {
            await this.stopSpeaking()
            await this.clean()
        } else {
            this.revertToReady()
        }
        this.speakingBase.noAuthLock = false
    }
    async handleOpenWebSocketError(
        errCode?: BridgeProto.ASpeakingState.ErrorType,
        clientErrorCode?: number
    ) {
        let content = this.messages?.socketNetworkErrorContent || SOCKET_NETWORK_ERROR_CONTENT
        if (clientErrorCode === 429) {
            // 跟读限流逻辑， PRD: https://confluence.zhenguanyu.com/pages/viewpage.action?pageId=167871381
            content = this.messages?.speakingLimitErrorContent || SPEAKING_LIMIT_ERROR_CONTENT
            this.onDialogCallback &&
                this.onDialogCallback({
                    title: BridgeUtil.isWin() ? this.messages?.socketNetworkErrorTitle || SOCKET_NETWORK_ERROR_TITLE : '',
                    content,
                    confirmButtonText: this.messages?.socketNetworkErrorConfirm || SOCKET_NETWORK_ERROR_CONFRIM,
                    cancelButtonText: this.messages?.socketNetworkErrorCancel || SOCKET_NETWORK_ERROR_CANCEL,
                    onConfirm: async () => {
                        await this.startSpeaking()
                    },
                    onCancel() {
                    },
                })
            return
        }
        // 统一放到中途异常处理，排除两次处理情况
        if (
            errCode &&
            [
                BridgeProto.ASpeakingState.ErrorType.WS_FAILURE,
                BridgeProto.ASpeakingState.ErrorType.WS_CONNECT_ERROR,
            ].includes(errCode)
        ) {
            // toast
            this.onToastCallback && this.onToastCallback(content)
        }
        if (errCode === BridgeProto.ASpeakingState.ErrorType.WS_CONNECT_ERROR) {
            // open socket 连接失败
            await this.speakingBase.stopRecorder()
            this.revertToReady()
        } else {
            await this.stopSpeaking()
            await this.clean()
        }
    }
    private uploadLogCheckMic(errorCode: BridgeProto.PermissionState | string) {
        if (errorCode === 'cancel') {
            this.updateSpeakingStatus(RecodingStatus.Disabled)
        }
    }
}
