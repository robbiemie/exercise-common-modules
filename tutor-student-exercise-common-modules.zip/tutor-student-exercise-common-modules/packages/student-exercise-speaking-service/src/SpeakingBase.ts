import {
    AuthorityManager,
    BaseSpeakingManager,
    BridgeProtoManager,
    BridgeUtil,
    WebAppEnv,
    WebProtoData,
    BridgeProto,
    container,
} from '@tutor/box-bridge-ts'
import { sleep } from './common/util'
import { Speaking } from '@tutor/exercise-speaking-proto'

export interface DialogOption {
    title: string
    content: string
    confirmButtonText?: string
    cancelButtonText?: string
    onCancel?: () => void
    onConfirm?: () => void
}

export interface Pronunciation {
    index: number
    pronunciation: string
}

interface Options {
    webAppId: string
    webAppVersion: string
    productId: string
    platform: string
    model: string
    userId: string
    businessParam: object
}


export default class SpeakingBase {

    public serveAddress: string = ''

    public noAuthCount: number = 0 // 无麦克风权限弹窗次数

    public noAuthLock: boolean = false // 弹窗加锁，防止二次弹窗

    public baseSpeakingManager: BaseSpeakingManager

    constructor() {
        if (BridgeUtil.checkEnv(WebAppEnv.Online)) {
            this.serveAddress = 'wss://www.yuanfudao.com/tutor-apeman-parrot/speaking'
        } else {
            this.serveAddress = 'wss://ke.yuanfudao.biz/tutor-apeman-parrot/speaking'
        }
        this.baseSpeakingManager = container.resolve(BaseSpeakingManager)
    }

    public async startRecorder(): Promise<void> {
        const promise = new Promise<void>((resolve, reject) => {
            this.baseSpeakingManager.startRecorder()
            const sucSub = this.baseSpeakingManager.onStartRecordingSuccess(() => {
                resolve()
                if (sucSub) {
                    sucSub.unsubscribe()
                }
                if (failSub) {
                    failSub.unsubscribe()
                }
            })

            const failSub = this.baseSpeakingManager.onStartRecordingFailed(() => {
                reject()
                if (sucSub) {
                    sucSub.unsubscribe()
                }
                if (failSub) {
                    failSub.unsubscribe()
                }
            })
        })
        return promise
    }

    public async openWebsocket(url?: string ) {
        const promise = new Promise<void>((resolve, reject) => {
            this.baseSpeakingManager.openWebsocket(url ? url : this.serveAddress)
            const sucSub = this.baseSpeakingManager.onWebSocketConnected(() => {
                resolve()
                if (sucSub) {
                    sucSub.unsubscribe()
                }
                if (failSub) {
                    failSub.unsubscribe()
                }
            })
            const failSub = this.baseSpeakingManager.onWebSocketConnectFailed(() => {
                reject(new Error('WebSocket Connect Failed'))
                if (sucSub) {
                    sucSub.unsubscribe()
                }
                if (failSub) {
                    failSub.unsubscribe()
                }
            })
        })
        return promise
    }
    /**
     * 打分服务初始化数据
     * @param text 跟读文本
     */
    public async startSpeaking(
        text: string,
        multiTexts: Speaking.ITextWithKeyWordsProto[],
        wordPronunciation: Pronunciation[],
        options: Options
    ) {
        // 发送跟读初始信息到打分服务端
        const upstream = Speaking.UpstreamMessage.create({
            type: Speaking.UpstreamMessage.UpstreamMessageType.INIT,
            text,
            multiTexts,
            params: [
                { key: 'productId', value: options.productId || '000' },
                {
                    key: 'platform',
                    value: options.platform || 'web',
                }, // platforms 平台不一样
                { key: 'model', value: options.model || '' },
                { key: 'sendVAD', value: 'true' },
                {
                    key: 'businessParam',
                    value: JSON.stringify({
                        busiType: 1,
                        ...options.businessParam
                    }),
                }, // 区分新作业
                {
                    key: 'wordPronunciation',
                    value: JSON.stringify(wordPronunciation),
                }, // 自定义发音
                { key: 'userId', value: options.userId || '1' },
                { key: 'webAppId', value: options.webAppId || '' },
                { key: 'webAppVersion', value: options.webAppVersion ||'APP_VERSION' },
            ],
        })
        return this.baseSpeakingManager.baseStartSpeaking(
            Speaking.UpstreamMessage.encode(upstream).finish(),
            BridgeProto.WStartSpeaking.SpeakingType.ENGLISH
        )
    }
    // 停止录音
    public async stopRecorder() {
        return new Promise((resolve, reject) => {
            this.baseSpeakingManager.getRecordingInfo().then(resolve).catch(reject)
            sleep(3000).then(() => {
                reject(new Error('timeout'))
            })
        })
            .catch(e => e)
            .then(info => {
                const recorderInfoString = info
                let params = null
                if (
                    recorderInfoString &&
                    (recorderInfoString as BridgeProto.WStopRecorderCallback)
                        .recordingInfo
                ) {
                    const json = JSON.parse(
                        (recorderInfoString as BridgeProto.WStopRecorderCallback)
                            .recordingInfo
                    )
                    params = Object.keys(json).map(key => {
                        return {
                            key,
                            value: `${json[key]}`,
                        }
                    })
                }
                return params
            })
    }

    /**
     * 停止和打分服务沟通
     * @param params record相关信息
     */
    public async stopSpeaking(params?: (Speaking.IKeyValue[]|null)) {
        const upstream = Speaking.UpstreamMessage.create({
            type: Speaking.UpstreamMessage.UpstreamMessageType.STOP,
            params,
        })

        return this.baseSpeakingManager.baseStopSpeaking(
            Speaking.UpstreamMessage.encode(upstream).finish()
        )
    }

    public onDownStreamMessage(
        handler: (msg: Speaking.IDownstreamMessage) => Promise<void>
    ) {
        return this.baseSpeakingManager.baseOnDownStreamMessage(
            (message: Uint8Array) => {
                const downStream = Speaking.DownstreamMessage.decode(message)
                handler(downStream)
            }
        )
    }

    public static ringBell(strUrl: string) {
        const bridgeProtoManager = container.resolve(BridgeProtoManager)
        return bridgeProtoManager.sendProto(WebProtoData.TypeCode.WRingBell, data => {
            data.url = strUrl
            data.speed = 1
        })
    }
    public static async setBGMVolume(volume: number) {
        const bridgeProtoManager = container.resolve(BridgeProtoManager)
        const supportVolume = await bridgeProtoManager.includeTypeCode(WebProtoData.TypeCode.WSetBGMVolume)
        if (supportVolume) {
            return bridgeProtoManager.sendProto(WebProtoData.TypeCode.WSetBGMVolume, (data: any) => {
                data.volume = volume
            })
        } else {
            return bridgeProtoManager.sendProto(WebProtoData.TypeCode.WMuteSpeaker, (data: any) => {
                data.mute = volume === 0 ? true : false
            })
        }
    }

    public static async checkMicAuthority() {
        return new Promise<void | {
            state: BridgeProto.PermissionState
            params: DialogOption
        }>(async (resolve, reject) => {
            const authorityManager = container.resolve(AuthorityManager)
            let requestionTypeCode: BridgeProto.WRequestPermissionCallback = null
            const content = BridgeUtil.isMac()
                ? '请按以下路径设置：系统偏好设置>安全性与隐私>隐私>麦克风，设置完成后需要重新启动客户端才可以生效。'
                : BridgeUtil.isWin()
                ? '麦克风启动失败'
                : '进行跟读练习需要开启麦克风权限'

            const dialogParam = {
                title: BridgeUtil.isMac()
                    ? '没有麦克风权限，无法进行跟读'
                    : BridgeUtil.isWin()
                    ? '提示'
                    : '',
                content,
                confirmButtonText: BridgeUtil.isWin() ? '' : '开启',
                cancelButtonText: BridgeUtil.isWin() ? '我知道了' : '取消',
                onConfirm: () => {
                    authorityManager.jumpSettingPage()
                },
                onCancel: () => {
                    reject('cancel')
                }
            }
            let checkTypeCode = null

            checkTypeCode = await authorityManager.checkPermission(
                BridgeProto.PermissionType.MICROPHONE
            )
            switch (checkTypeCode && checkTypeCode.state) {
                case BridgeProto.PermissionState.GRANTED:
                    resolve()
                    break
                case BridgeProto.PermissionState.NOT_DETERMINED:
                case BridgeProto.PermissionState.UNKNOWN_STATE:
                    requestionTypeCode = await authorityManager.getPermission(
                        BridgeProto.PermissionType.MICROPHONE
                    )
                    switch (requestionTypeCode.state) {
                        case BridgeProto.PermissionState.GRANTED:
                            resolve()
                            break
                        default:
                            reject(checkTypeCode.state)
                            break
                    }
                    break
                default:
                    reject(checkTypeCode.state)
                    break
            }
        })
    }

    public closeWebsocket() {
        return new Promise<void>((resolve, reject) => {
            this.baseSpeakingManager.closeWebsocket().then(resolve).catch(reject)
            sleep(5000).then(() => reject(new Error('timeout')))
        })
    }
}
