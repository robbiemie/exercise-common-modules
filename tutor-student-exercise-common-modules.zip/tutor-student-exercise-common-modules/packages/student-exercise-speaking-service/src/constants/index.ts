export enum RecodingStatus {
    'Idle' = 'Idle',
    'Loading' = 'Loading',
    'Disabled' = 'Disabled', // 禁用麦克风
    'RecordStart' = 'RecordStart', // 录音开始
    'ConnectionSuccess' = 'ConnectionSuccess', // 建立连接成功
    'ConnectionFail' = 'ConnectionFail', // 建立连接失败
    'StartRecorderFail' = 'StartRecorderFail', // 初始化失败
    'RecordCheckSuccess' = 'RecordCheckSuccess', // 录音校验通过
    'RecordCheckFail' = 'RecordCheckFail', // 录音校验失败
    'RecordStartFail' = 'RecordStartFail', // 录音失败
    'RecordRunning' = 'RecordRunning', // 录音过程中
    'RecordEnd' = 'RecordEnd', // 录音结束
}
export enum ErrorCode {
    'Micphone' = 1001, // 麦克风异常
    'Websocket' = 1002, // websocket 异常
    'StartRecorder' = 1003, // 初始化录音异常
    'StartSpeaking' = 1004, // 开始跟读异常
    'StopRecorder' = 1005, // 停止录音异常
    'StopSpeaking' = 1006, // 结束跟读异常
}

export enum SpeakingHooksType {
    'BeforeCheckMicAuthority' = 'BeforeCheckMicAuthority',
    'BeforeStartRecorder' = 'BeforeStartRecorder',
    'BeforeOpenWebsocket' = 'BeforeOpenWebsocket',
    'BeforeStartSpeaking' = 'BeforeStartSpeaking',
    'BeforeStopRecorder' = 'BeforeStopRecorder',
    'BeforeStopSpeaking' = 'BeforeStopSpeaking',
    'AfterStopSpeaking' = 'AfterStopSpeaking'
}
