// 10s 未返回打分结果弹窗提示
export const NO_RESULT_TITLE = '提示'
export const NO_RESULT_CONTENT = '跟读提交失败，请重新跟读'
export const NO_RESULT_CONFRIM = '再读一遍'
export const NO_RESULT_CANCEL = '取消'
// 网络异常提示
export const NETWORK_ERROR_TITLE = '提示'
export const NETWORK_ERROR_CONTENT = '网络异常，请检查网络连接后重新跟读'
export const NETWORK_ERROR_CONTRIM = '我知道了'
// 麦克风权限提示
export const MIC_AUTHORITY_TITLE = '提示'
export const NO_MIC_AUTHORITY_CONTENT = '跟读需要开启麦克风权限'
export const NO_MIC_AUTHORITY_CONFIRM = '去设置'
export const MIC_AUTHORITY_ERROR_CONTENT = '麦克风启动失败'
export const MIC_AUTHORITY_ERROR_CONFIRM = '我知道了'
// socket 建立网络连接失败
export const SOCKET_NETWORK_ERROR_TITLE = '提示'
export const SOCKET_NETWORK_ERROR_CONTENT = '网络异常，请检查网络连接后重新跟读'
export const SPEAKING_LIMIT_ERROR_CONTENT = '网络繁忙，暂时无法跟读'
export const SOCKET_NETWORK_ERROR_CONFRIM = '再读一遍'
export const SOCKET_NETWORK_ERROR_CANCEL = '取消'
