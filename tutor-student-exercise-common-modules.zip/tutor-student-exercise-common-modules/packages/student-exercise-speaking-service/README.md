# `@tutor/student-exercise-speaking-service`

> TODO: description

## Usage

```
const studentExerciseUaDevice = require('@tutor/student-exercise-speaking-service');

// TODO: DEMONSTRATE API
```
