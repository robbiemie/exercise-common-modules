# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

### [0.0.13-1](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/compare/v0.0.2...v0.0.13-1) (2021-09-18)


### Features

* 升级box-bridge版本 ([df5a63a](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/df5a63a3b512ea5e5295b5903a867d3b1da0d63d))
* **image-load:** 新增 isShowLoadingOnce 属性，用于控制 loading 展示 ([fd02f70](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/fd02f70ce5b2655df656a1b5d7efe24b0f99ae16))
* 开启跟读,新增异常状态回调 ([6b9ab1f](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/6b9ab1fcc629eed80df76fe7877db925b729fc20))
* 新增 speakingHooks ([6d5ce1a](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/6d5ce1ae58e306ea466e7d15cad92cc0d67b188e))
* 新增running状态 ([6ec51f6](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/6ec51f60fb20d69f0fd596e2bfc39baea12718a6))
* 补充 ringBell 接口 ([8db78c4](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/8db78c4917845f5180440dd514b4af2334a6cb39))
* 补充多文本跟读场景 ([6922aab](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/6922aabd1eb423e1e4413e5f80f1ba5b6b40a823))


### Bug Fixes

* 优化 speaking 流程 ([a38ec10](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/a38ec1005b915140d274586ae297f2d9702297c8))
* 修改box-bridge-ts依赖 ([14fb420](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/14fb4202b68d703a5cfffeb52f2da39aab055685))
* 修改开始跟读异常处理逻辑 ([63167cb](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/63167cbc55e5c425f4ed2ee8971453b488fd9a0c))
* 修改格式 ([8cb1998](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/8cb199826202886c87e76a16c475674a8cfab21c))
* 处理异常场景 ([d05b626](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/d05b62600fe67e58ff9547211a745059dcc7310d))
* 提取公共方法 checkMicAuthority ([b9c86a1](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/b9c86a1e4d195d8c0dab3e785fd8f61e9b990709))
* 新增获取麦克风权限异常逻辑 ([091d33e](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/091d33e7eda47df36ec66e3c469ab6d227a48e09))
* 替换 ringBell static 修饰符 && 默认不打tag ([4ffd0c9](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/4ffd0c9b8065f226b78ccc3655f24250ed330d23))
* 补充 callback type ([3d8ee61](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/3d8ee61c69417dd81f258f9a4088a406e6c880b7))

### [0.0.13-0](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/compare/v0.0.2...v0.0.13-0) (2021-09-17)


### Features

* 升级box-bridge版本 ([df5a63a](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/df5a63a3b512ea5e5295b5903a867d3b1da0d63d))
* **image-load:** 新增 isShowLoadingOnce 属性，用于控制 loading 展示 ([fd02f70](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/fd02f70ce5b2655df656a1b5d7efe24b0f99ae16))
* 开启跟读,新增异常状态回调 ([6b9ab1f](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/6b9ab1fcc629eed80df76fe7877db925b729fc20))
* 新增 speakingHooks ([6d5ce1a](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/6d5ce1ae58e306ea466e7d15cad92cc0d67b188e))
* 新增running状态 ([6ec51f6](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/6ec51f60fb20d69f0fd596e2bfc39baea12718a6))
* 补充 ringBell 接口 ([8db78c4](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/8db78c4917845f5180440dd514b4af2334a6cb39))
* 补充多文本跟读场景 ([6922aab](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/6922aabd1eb423e1e4413e5f80f1ba5b6b40a823))


### Bug Fixes

* 优化 speaking 流程 ([a38ec10](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/a38ec1005b915140d274586ae297f2d9702297c8))
* 修改开始跟读异常处理逻辑 ([63167cb](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/63167cbc55e5c425f4ed2ee8971453b488fd9a0c))
* 修改格式 ([8cb1998](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/8cb199826202886c87e76a16c475674a8cfab21c))
* 处理异常场景 ([d05b626](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/d05b62600fe67e58ff9547211a745059dcc7310d))
* 提取公共方法 checkMicAuthority ([b9c86a1](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/b9c86a1e4d195d8c0dab3e785fd8f61e9b990709))
* 新增获取麦克风权限异常逻辑 ([091d33e](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/091d33e7eda47df36ec66e3c469ab6d227a48e09))
* 替换 ringBell static 修饰符 && 默认不打tag ([4ffd0c9](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/4ffd0c9b8065f226b78ccc3655f24250ed330d23))
* 补充 callback type ([3d8ee61](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/3d8ee61c69417dd81f258f9a4088a406e6c880b7))

### [0.0.12](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/compare/v0.0.2...v0.0.12) (2021-09-14)


### Features

* 开启跟读,新增异常状态回调 ([6b9ab1f](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/6b9ab1fcc629eed80df76fe7877db925b729fc20))
* 新增 speakingHooks ([6d5ce1a](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/6d5ce1ae58e306ea466e7d15cad92cc0d67b188e))
* 新增running状态 ([6ec51f6](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/6ec51f60fb20d69f0fd596e2bfc39baea12718a6))
* 补充 ringBell 接口 ([8db78c4](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/8db78c4917845f5180440dd514b4af2334a6cb39))
* 补充多文本跟读场景 ([6922aab](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/6922aabd1eb423e1e4413e5f80f1ba5b6b40a823))


### Bug Fixes

* 优化 speaking 流程 ([a38ec10](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/a38ec1005b915140d274586ae297f2d9702297c8))
* 修改开始跟读异常处理逻辑 ([63167cb](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/63167cbc55e5c425f4ed2ee8971453b488fd9a0c))
* 修改格式 ([8cb1998](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/8cb199826202886c87e76a16c475674a8cfab21c))
* 处理异常场景 ([d05b626](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/d05b62600fe67e58ff9547211a745059dcc7310d))
* 提取公共方法 checkMicAuthority ([b9c86a1](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/b9c86a1e4d195d8c0dab3e785fd8f61e9b990709))
* 新增获取麦克风权限异常逻辑 ([091d33e](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/091d33e7eda47df36ec66e3c469ab6d227a48e09))
* 替换 ringBell static 修饰符 && 默认不打tag ([4ffd0c9](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/4ffd0c9b8065f226b78ccc3655f24250ed330d23))
* 补充 callback type ([3d8ee61](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/3d8ee61c69417dd81f258f9a4088a406e6c880b7))

### [0.0.11](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/compare/v0.0.2...v0.0.11) (2021-09-13)


### Features

* 开启跟读,新增异常状态回调 ([6b9ab1f](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/6b9ab1fcc629eed80df76fe7877db925b729fc20))
* 新增running状态 ([6ec51f6](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/6ec51f60fb20d69f0fd596e2bfc39baea12718a6))
* 补充 ringBell 接口 ([8db78c4](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/8db78c4917845f5180440dd514b4af2334a6cb39))
* 补充多文本跟读场景 ([6922aab](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/6922aabd1eb423e1e4413e5f80f1ba5b6b40a823))


### Bug Fixes

* 优化 speaking 流程 ([a38ec10](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/a38ec1005b915140d274586ae297f2d9702297c8))
* 处理异常场景 ([d05b626](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/d05b62600fe67e58ff9547211a745059dcc7310d))
* 提取公共方法 checkMicAuthority ([b9c86a1](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/b9c86a1e4d195d8c0dab3e785fd8f61e9b990709))
* 新增获取麦克风权限异常逻辑 ([091d33e](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/091d33e7eda47df36ec66e3c469ab6d227a48e09))
* 替换 ringBell static 修饰符 && 默认不打tag ([4ffd0c9](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/4ffd0c9b8065f226b78ccc3655f24250ed330d23))
* 补充 callback type ([3d8ee61](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/3d8ee61c69417dd81f258f9a4088a406e6c880b7))

### [0.0.10](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/compare/v0.0.2...v0.0.10) (2021-09-13)


### Features

* 开启跟读,新增异常状态回调 ([6b9ab1f](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/6b9ab1fcc629eed80df76fe7877db925b729fc20))
* 新增running状态 ([6ec51f6](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/6ec51f60fb20d69f0fd596e2bfc39baea12718a6))
* 补充 ringBell 接口 ([8db78c4](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/8db78c4917845f5180440dd514b4af2334a6cb39))
* 补充多文本跟读场景 ([6922aab](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/6922aabd1eb423e1e4413e5f80f1ba5b6b40a823))


### Bug Fixes

* 优化 speaking 流程 ([a38ec10](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/a38ec1005b915140d274586ae297f2d9702297c8))
* 处理异常场景 ([d05b626](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/d05b62600fe67e58ff9547211a745059dcc7310d))
* 提取公共方法 checkMicAuthority ([b9c86a1](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/b9c86a1e4d195d8c0dab3e785fd8f61e9b990709))
* 替换 ringBell static 修饰符 && 默认不打tag ([4ffd0c9](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/4ffd0c9b8065f226b78ccc3655f24250ed330d23))
* 补充 callback type ([3d8ee61](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/3d8ee61c69417dd81f258f9a4088a406e6c880b7))

### [0.0.9](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/compare/v0.0.2...v0.0.9) (2021-09-10)


### Features

* 新增running状态 ([6ec51f6](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/6ec51f60fb20d69f0fd596e2bfc39baea12718a6))
* 补充 ringBell 接口 ([8db78c4](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/8db78c4917845f5180440dd514b4af2334a6cb39))
* 补充多文本跟读场景 ([6922aab](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/6922aabd1eb423e1e4413e5f80f1ba5b6b40a823))


### Bug Fixes

* 优化 speaking 流程 ([a38ec10](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/a38ec1005b915140d274586ae297f2d9702297c8))
* 处理异常场景 ([d05b626](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/d05b62600fe67e58ff9547211a745059dcc7310d))
* 提取公共方法 checkMicAuthority ([b9c86a1](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/b9c86a1e4d195d8c0dab3e785fd8f61e9b990709))
* 替换 ringBell static 修饰符 && 默认不打tag ([4ffd0c9](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/4ffd0c9b8065f226b78ccc3655f24250ed330d23))
* 补充 callback type ([3d8ee61](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/3d8ee61c69417dd81f258f9a4088a406e6c880b7))

### [0.0.8](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/compare/v0.0.2...v0.0.8) (2021-09-09)


### Features

* 新增running状态 ([6ec51f6](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/6ec51f60fb20d69f0fd596e2bfc39baea12718a6))
* 补充 ringBell 接口 ([8db78c4](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/8db78c4917845f5180440dd514b4af2334a6cb39))


### Bug Fixes

* 优化 speaking 流程 ([a38ec10](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/a38ec1005b915140d274586ae297f2d9702297c8))
* 提取公共方法 checkMicAuthority ([b9c86a1](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/b9c86a1e4d195d8c0dab3e785fd8f61e9b990709))
* 替换 ringBell static 修饰符 && 默认不打tag ([4ffd0c9](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/4ffd0c9b8065f226b78ccc3655f24250ed330d23))

### [0.0.7](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/compare/v0.0.2...v0.0.7) (2021-09-08)


### Features

* 补充 ringBell 接口 ([8db78c4](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/8db78c4917845f5180440dd514b4af2334a6cb39))


### Bug Fixes

* 优化 speaking 流程 ([a38ec10](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/a38ec1005b915140d274586ae297f2d9702297c8))
* 提取公共方法 checkMicAuthority ([b9c86a1](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/b9c86a1e4d195d8c0dab3e785fd8f61e9b990709))
* 替换 ringBell static 修饰符 && 默认不打tag ([4ffd0c9](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/4ffd0c9b8065f226b78ccc3655f24250ed330d23))

### [0.0.6](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/compare/v0.0.2...v0.0.6) (2021-09-03)


### Features

* 补充 ringBell 接口 ([8db78c4](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/8db78c4917845f5180440dd514b4af2334a6cb39))


### Bug Fixes

* 优化 speaking 流程 ([a38ec10](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/a38ec1005b915140d274586ae297f2d9702297c8))
* 替换 ringBell static 修饰符 && 默认不打tag ([4ffd0c9](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/4ffd0c9b8065f226b78ccc3655f24250ed330d23))

### [0.0.5](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/compare/v0.0.2...v0.0.5) (2021-09-01)


### Features

* 补充 ringBell 接口 ([8db78c4](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/8db78c4917845f5180440dd514b4af2334a6cb39))


### Bug Fixes

* 替换 ringBell static 修饰符 && 默认不打tag ([4ffd0c9](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/4ffd0c9b8065f226b78ccc3655f24250ed330d23))

### [0.0.4](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/compare/v0.0.2...v0.0.4) (2021-09-01)


### Features

* 补充 ringBell 接口 ([8db78c4](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/8db78c4917845f5180440dd514b4af2334a6cb39))


### Bug Fixes

* 替换 ringBell static 修饰符 && 默认不打tag ([4ffd0c9](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/4ffd0c9b8065f226b78ccc3655f24250ed330d23))

### [0.0.3](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/compare/v0.0.2...v0.0.3) (2021-09-01)


### Features

* 补充 ringBell 接口 ([8db78c4](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/8db78c4917845f5180440dd514b4af2334a6cb39))

### [0.0.2](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/compare/v0.0.1...v0.0.2) (2021-09-01)


### Features

* 抽离 speakingService 组件v2 ([3a2d7e9](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/3a2d7e9bc6f9e17342043c8c3f4d775f3afa7824))
* 部分变量重命名 ([c749528](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/c74952838707527c5d3d9385b4b034dfddb099a4))

### [0.0.1](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/compare/v0.0.7...v0.0.1) (2021-08-31)


### Features

* 创建种子项目 ([c0e46e4](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/c0e46e4dcec34f1c8f919903c3ebf95a72335808))
* 初始化项目 ([f947b8f](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/f947b8f8d93f41911adaa4d3741b0b22d2649b6e))
* 抽离跟读组件 ([80a7810](http://gerrit.zhenguanyu.com:29418/29418/tutor-student-exercise-common-modules/commit/80a781081bf95d4bdb625461b535430e4febaa7f))
